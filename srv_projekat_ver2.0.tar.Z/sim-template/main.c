/**
 * @file main.c
 * @author Nikola Jugovic 0408/2016
 * @date 11.09.2020.
 * @brief Real-time system project ver:2.0
 *
 *
 * Calculating arithmetic mean of 4 last values for every chanel and showing them using UART

 */

/* Standard includes. */
#include <stdio.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"
#include "queue.h"
#include "uart.h"

/* Hardware includes. */
#include "msp430.h"
#include "hal_ETF5438A.h"

/* Macro used for starting ADC sequence of conversions. */
#define adcSTART_CONV do  {ADC12CTL0 |= ADC12SC;} while(0)

/* ADC sample timer period */
#define adcAQUISITION_PERIOD (pdMS_TO_TICKS(1000))
#define mainTIMER_DEBOUNCE_PERIOD    ( pdMS_TO_TICKS( 20 ) )
#define mainTIMER_34_PERIOD      ( pdMS_TO_TICKS( 10 ) )
/*Length off array used for getting values gathered from ADC */
#define adcADC_DATA_QUEUE_LEN   ( 16 )
/*Task priorities*/
#define mainLP_TASK_PRIO        ( 1 )
#define mainMP_TASK_PRIO 		(2)
#define adcTASK_PRIO            ( 4 )
#define mainHP_TASK_PRIO        (3)
static QueueHandle_t xTaskQueue = NULL;
static QueueHandle_t xADCDataQueue = NULL;
/* Initializing queueSet variables */
QueueSetHandle_t xQueueDataSet = NULL;
QueueSetMemberHandle_t xActivatedMember = NULL;
/*Initialiazing semaphores*/
SemaphoreHandle_t xTask2Debounce=NULL;
SemaphoreHandle_t xTask34Debounce=NULL;
/*Initializing timers */
static TimerHandle_t xTimerDebounce = NULL;
static TimerHandle_t xTimer34 = NULL;


/*Initializing tasks */
TaskHandle_t xTask1Handler = NULL;
TaskHandle_t xTask2Handler = NULL;
TaskHandle_t xTask3Handler = NULL;
TaskHandle_t xTask4Handler = NULL;
TaskHandle_t xADCTaskADC = NULL;
static void prvSetupHardware(void);

/* Table of ASCII values  */
const unsigned int ASCII[] = {
   48,  //0
   49,  //1
   50,
   51,
   52,
   53,
   54,
   55,
   56,
   57,  //9
   65,  //A
   66,  //B
   67,  //C
   68,  //D
   69,  //E
   70   //F
};
/* Type for defining channels*/
typedef enum {
    CH0,
    CH1,
    CH2,
    CH3
} Channel_t;
/*Struct used for saving number of chanel and converted data*/
typedef struct
{
    Channel_t eADCNr;   //serial number of chanel
    uint8_t usADCData; //8bit result of AD conversion

} ADCMsg_t;
/*
 * @brief Starting AD conversion every 1000ms, high priority task
 */
static void xTaskTimer (void *pvParameters) {
    TickType_t xLastWakeTime;

    for (;;){

        xLastWakeTime = xTaskGetTickCount();
        adcSTART_CONV;
        vTaskDelayUntil(&xLastWakeTime,adcAQUISITION_PERIOD);
    }
}
/*
 * @brief Medium priority task
 * Task used for gathering data from queues and counting averege values for last 4 values of
 * every channel.
 * Gathered values Task1 sends to Task3 or Task4 using direct task notification depend on choosen button in Task2.
 * Task1 is getting information from Task2 with special queue
 *
 */
static void Task1(void *pvParameters) {
    uint32_t FinalData;            //32bit value for sending to task3 or task4
ADCMsg_t xData;                     //number of chanel and value from ADC


    uint32_t CH0[4]={0,0,0,0};       //arrays for putting values in;when new value comes, last value goes out
    uint32_t CH1[4]={0,0,0,0};
    uint32_t CH2[4]={0,0,0,0};
    uint32_t CH3[4]={0,0,0,0};
    uint32_t mid0;      //mid value of every chanel
    uint32_t mid1;
    uint32_t mid2;
    uint32_t mid3;
    uint8_t S;          //chosing task to send

    for (;;){
        xActivatedMember = xQueueSelectFromSet( xQueueDataSet, portMAX_DELAY);  //getting queue from ququeSet which has some values//
        if (xActivatedMember == xADCDataQueue){
            /*Cheking is queue have any values  */
            configASSERT(xQueueReceive(xADCDataQueue, &xData, portMAX_DELAY)==pdTRUE);
            /*In case that array have some values, start putting them in array and counting average */
        switch(xData.eADCNr)
                {
                case 0:
                   //P4OUT ^= BIT3;
                    /* When new value is detected, all values in array are shifting. */
                    CH0[3]=CH0[2];
                    CH0[2]=CH0[1];
                    CH0[1]=CH0[0];
                    CH0[0]=xData.usADCData;
                    mid0=(CH0[0]+CH0[1]+CH0[2]+CH0[3])/4 << 24;

                    break;

                case 1:
                  // P4OUT ^= BIT4;
                    CH1[3]=CH1[2];
                    CH1[2]=CH1[1];
                    CH1[1]=CH1[0];
                    CH1[0]=xData.usADCData;
                    mid1=((CH1[0]+CH1[1]+CH1[2]+CH1[3])/4) << 16;

					break;

                case 2:
                  //  P4OUT ^= BIT5;
                    CH2[3]=CH2[2];
                    CH2[2]=CH2[1];
                    CH2[1]=CH2[0];
                    CH2[0]=xData.usADCData;
                    mid2=((CH2[0]+CH2[1]+CH2[2]+CH2[3])/4)<<8;

                    break;

                case 3:
                   // P4OUT ^= BIT6;
                    CH3[3]=CH3[2];
                    CH3[2]=CH3[1];
                    CH3[1]=CH3[0];
                    CH3[0]=xData.usADCData;
                    mid3=((CH3[0]+CH3[1]+CH3[2]+CH3[3])/4);

                    break;

                }
                /*Putting all averege values in one 32bit value */
                FinalData= mid0 | mid1 | mid2 | mid3;
                /*Checking which channel is choosen */
                if (S == 0x50) {
                    xTaskNotify( xTask3Handler, FinalData, eSetValueWithOverwrite );

                }
                if (S == 0x80) {
                    xTaskNotify( xTask4Handler, FinalData, eSetValueWithOverwrite );

                }
        } else  if (xActivatedMember == xTaskQueue) {
            /*Checking is any button pressed */
           configASSERT(xQueueReceive(xTaskQueue, &S, portMAX_DELAY) == pdTRUE);
        }
    }
}
/*
 * @brief Low priority task
 * Task used for checking buttons. Buttons are debounced using binary semaphore and timer.
 * Comparing previous and current value, task is checking buttons. Using xTaskQueue, Task2 is sending information
 * which button is pressed to task1.
 */
static void Task2(void *pvParameters) {
    uint8_t ucLastState3 = 0, ucState3 = 0;
    uint8_t ucLastState4 = 0, ucState4 = 0;
    uint8_t S3=0x50;            //BIT6
    uint8_t S4=0x80;            //BIT7
    for (;;){
        xSemaphoreTake(xTask2Debounce,portMAX_DELAY);   //taking semaphor, and realising every 20ms
        ucState3= P2IN & BIT6;
        if ((ucState3 == 0) && (ucLastState3 == BIT6)){
            xQueueSend(xTaskQueue, &S3,portMAX_DELAY);

        }
        ucLastState3=ucState3;

        ucState4= P2IN & BIT7;
        if ((ucState4 == 0) && (ucLastState4 == BIT7)){
            xQueueSend(xTaskQueue, &S4,portMAX_DELAY);

        }
        ucLastState4=ucState4;
     }
}
/*
 * @brief Low priority task
 * Task used for showing gathered values from Task1 using UART.
 */
static void Task3 (void *pvParameters)
{
    static uint32_t tempBits;
    static uint8_t ch0h=0;      //higher 4 bits
    static uint8_t ch0l=0;      //lower 4 bits
    static uint8_t ch1h=0;
    static uint8_t ch1l=0;
    static uint8_t ch2h=0;
    static uint8_t ch2l=0;
    static uint8_t ch3h=0;
    static uint8_t ch3l=0;
    char data[20];
    for(;;){
        xSemaphoreTake( xTask34Debounce, portMAX_DELAY);
        xTaskNotifyWait( 0, 0xffffffff,  &tempBits, portMAX_DELAY);//dont clear entry bits; clear bits on exit
        ch3h=(tempBits >> 28) &0xF;
        ch3l=(tempBits >> 24) &0xF;
        ch2h=(tempBits >> 20) &0xF;
        ch2l=(tempBits >> 16) &0xF;
        ch1h=(tempBits >> 12) &0xF;
        ch1l=(tempBits >> 8) &0xF;
        ch0h=(tempBits >> 4) &0xF;
        ch0l=(tempBits ) & 0x0F;

        sprintf(data, "Task3:%c", ASCII[ch3h] );
        xUartSendString(data, 0);
        sprintf(data, "%c ", ASCII[ch3l] );
        xUartSendString(data, 0);
        sprintf(data, "%c", ASCII[ch2h] );
        xUartSendString(data, 0);
        sprintf(data, "%c ", ASCII[ch2l] );
        xUartSendString(data, 0);
        sprintf(data, "%c", ASCII[ch1h] );
        xUartSendString(data, 0);
        sprintf(data, "%c ", ASCII[ch1l] );
        xUartSendString(data, 0);
        sprintf(data, "%c", ASCII[ch0h] );
        xUartSendString(data, 0);
        sprintf(data, "%c\r\n", ASCII[ch0l] );
        xUartSendString(data, 0);


    }
}
/*
 * @brief Low priority task
 * Task used for showing gathered values from Task1 using UART.
 */
static void Task4 (void *pvParameters)
{
    static uint32_t tempBits;
    static uint8_t ch0h=0;
    static uint8_t ch0l=0;
    static uint8_t ch1h=0;
    static uint8_t ch1l=0;
    static uint8_t ch2h=0;
    static uint8_t ch2l=0;
    static uint8_t ch3h=0;
    static uint8_t ch3l=0;
    char data[20];
    for(;;){
            xSemaphoreTake( xTask34Debounce, portMAX_DELAY);
            xTaskNotifyWait( 0, 0xffffffff,  &tempBits, portMAX_DELAY);//dont clear entry bits; clear bits on exit
            ch3h=(tempBits >> 28) &0xF;
            ch3l=(tempBits >> 24) &0xF;
            ch2h=(tempBits >> 20) & 0xF;
            ch2l=(tempBits >> 16) & 0xF;
            ch1h=(tempBits >> 12) & 0xF;
            ch1l=(tempBits >> 8) & 0xF;
            ch0h=(tempBits >> 4) & 0xF;
            ch0l=(tempBits ) & 0x0F;

            sprintf(data, "Task4:%c", ASCII[ch3h] );
            xUartSendString(data, 0);
            sprintf(data, "%c ", ASCII[ch3l] );
            xUartSendString(data, 0);
            sprintf(data, "%c", ASCII[ch2h] );
            xUartSendString(data, 0);
            sprintf(data, "%c ", ASCII[ch2l] );
            xUartSendString(data, 0);
            sprintf(data, "%c", ASCII[ch1h] );
            xUartSendString(data, 0);
            sprintf(data, "%c ", ASCII[ch1l] );
            xUartSendString(data, 0);
            sprintf(data, "%c", ASCII[ch0h] );
            xUartSendString(data, 0);
            sprintf(data, "%c\r\n", ASCII[ch0l] );
            xUartSendString(data, 0);

        }
}
/*
 * @brief Timer debounce callback for realising debouncing semaphore
 * every 20ms
 *
 */
static void vTimerDebounceCallback (TimerHandle_t xTimer) {
    xSemaphoreGive( xTask2Debounce );
}
/*
 * @brief Timer used for Task3 and Task4 which realising semaphore every 10ms
 *
 */
static void vTimer34Callback(TimerHandle_t xTimer)
{
	xSemaphoreGive(xTask34Debounce);
	}


/**
 * @brief main function
 * Main function is used for creating all tasks,timers,semaphores,queues and queueSet.
 * Also main is used for starting timers and calling hardware initialization function
 */
void main (void) {

    xTaskCreate (Task1,"Task1",configMINIMAL_STACK_SIZE, NULL,mainMP_TASK_PRIO, &xTask1Handler);
	xTaskCreate (Task2,"Task2",configMINIMAL_STACK_SIZE, NULL,mainLP_TASK_PRIO,&xTask2Handler);
    xTaskCreate(Task3,"Task3",configMINIMAL_STACK_SIZE,NULL, mainLP_TASK_PRIO, &xTask3Handler );
    xTaskCreate(Task4,"Task4",configMINIMAL_STACK_SIZE,NULL, mainLP_TASK_PRIO, &xTask4Handler );
	xTaskCreate(xTaskTimer, "ADC Task",configMINIMAL_STACK_SIZE, NULL,adcTASK_PRIO,&xADCTaskADC);
	xTimerDebounce=xTimerCreate("TimerDebounce",mainTIMER_DEBOUNCE_PERIOD,pdTRUE,NULL,vTimerDebounceCallback);
	xTimer34=xTimerCreate("Timer34",mainTIMER_34_PERIOD,pdTRUE,NULL,vTimer34Callback);
	
	xTask34Debounce=xSemaphoreCreateBinary();
    xTask2Debounce = xSemaphoreCreateBinary();
	
    xTimerStart(xTimer34,0);
    xTimerStart( xTimerDebounce, 0 );
	


    xTaskQueue = xQueueCreate(1,sizeof(uint8_t));
	xADCDataQueue =xQueueCreate(adcADC_DATA_QUEUE_LEN, sizeof(ADCMsg_t));

	xQueueDataSet = xQueueCreateSet (10);
	    /* Add two created queues to the set. */
    xQueueAddToSet(xADCDataQueue, xQueueDataSet);
    xQueueAddToSet(xTaskQueue, xQueueDataSet);

	vUartInit();
	prvSetupHardware();
    vTaskStartScheduler();
    for(;;);
}

/**
 * @brief Hardware initialization funciton
 */

static void prvSetupHardware( void )
{
    taskDISABLE_INTERRUPTS();

    /* Disable the watchdog. */
    WDTCTL = WDTPW + WDTHOLD;

    /* Configure Clock. Since we aren't using XT1 on the board,
     * configure REFOCLK to source FLL adn ACLK.
     */
    SELECT_FLLREF(SELREF__REFOCLK);
    SELECT_ACLK(SELA__REFOCLK);
    hal430SetSystemClock( configCPU_CLOCK_HZ, configLFXT_CLOCK_HZ );
    /* Enable LED display */
       P11DIR |= BIT0 + BIT1;
       P10DIR |= BIT6 + BIT7;
       P6DIR = 0x7F;

       /* Enable buttons */
       P2DIR &= ~(0xF0);
       P4DIR |= 0x78;
       P4OUT = 0x00;
       /* Initialize necessary hardware */
       vADCInitHardware();
   }
/**
 * @brief ADC hardware initialization
 */
void vADCInitHardware (void) {

        P7SEL |= BIT6 + BIT7;
        P5SEL |= BIT0 + BIT1;
        /* ADC */
        ADC12CTL0 = ADC12ON | ADC12MSC;     /* using MSC */
        ADC12CTL1 = ADC12SHS_0 | ADC12CONSEQ_1 | ADC12SHP;  /* repeat-sequence */
        ADC12MCTL0 = ADC12INCH_14;
        ADC12MCTL1 = ADC12INCH_15;
        ADC12MCTL2 = ADC12INCH_8;
        ADC12MCTL3 = ADC12INCH_9 | ADC12EOS;    /* MEM3 ned of seq */
       ADC12IE |= ADC12IE0 | ADC12IE1 | ADC12IE2 | ADC12IE3;   /* allow interrupts */
       ADC12CTL0 |= ADC12ENC;      /* allow conversion */
   }
/**
 * @brief ADC interrupt service routine
 * Interrupt is starting every 1000ms, and sending top 8 bits of conversion to queue
 *
 */
void __attribute__((interrupt(ADC12_VECTOR))) vADCISR(void){
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    switch(ADC12IV)
    {
        case 6:
            {    P4OUT ^=BIT3;  //diodes used for indicationg conversion

                ADCMsg_t xMsg = {CH0, ADC12MEM0 >> 4};
                xQueueSendToBackFromISR(xADCDataQueue, &xMsg,&xHigherPriorityTaskWoken);
            }
            break;
        case 8:
            {    P4OUT ^=BIT4;

                ADCMsg_t xMsg = {CH1, ADC12MEM1 >> 4};
                xQueueSendToBackFromISR( xADCDataQueue, &xMsg, &xHigherPriorityTaskWoken );
            }
            break;
        case 10:                    /* Vector 10: ADC12IFG2 */
            {    P4OUT ^=BIT5;

                ADCMsg_t xMsg = { CH2, ADC12MEM2 >> 4 };
                xQueueSendToBackFromISR( xADCDataQueue, &xMsg, &xHigherPriorityTaskWoken );
            }
            break;
        case 12:                    /* Vector 12: ADC12IFG3 */
            {    P4OUT ^=BIT6;

                ADCMsg_t xMsg = { CH3, ADC12MEM3 >> 4 };
                xQueueSendToBackFromISR( xADCDataQueue, &xMsg, &xHigherPriorityTaskWoken );
            }
            break;
        default: break;
    }
}



















