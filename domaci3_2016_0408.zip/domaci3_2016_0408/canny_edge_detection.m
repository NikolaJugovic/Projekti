function J=canny_edge_detection(I,s,tl,th)
%Funckija za detekciju ivica slike koriscenjem canny-jevog algoritma
%Ulazni parametri funkcije 
%I -> Ulazna slika kojoj treba detektovati ivice u double formatu
%s -> Standardna devijacija Gausove funkcije
%tl -> Apsolutna vrednost nizeg praga
%th -> Apsolutna vrednost viseg praga
%Postupak funkcije 
%1. Filtriranje ulazne slike Gausovom funkcijom zadate standardne devijacije. Za veli?inu prozora Gausove funkcije uzeti prvi neparni ceo ve?i ili jednak od 6 sigma. 
%2. Odredjivanje horizontalnih i vertikalnih gradijenata tako filtrirane slike. 
%3. Odredjivanje magnitude i ugla gradijenta. 
%4. Kvantizacija gradijenta na jedan od 4 pravaca -45o, 0 o, 45 o, 90 o. 
%5. Potiskivanje vrednosti gradijenata koje ne predstavljaju lokalne maksimume.
%6. Odredjivanje mapa jakih i slabih ivica na osnovu vrednosti ni�eg i vi�eg praga.
%7. Ukljucivanje u izlaznu mapu ivica onih slabih ivica koje su povezane sa nekom jakom ivicom.
    
    I=im2double(I);
    sir=ceil(6*s);
    prozor=fspecial('gaussian',[sir sir],s);
    
%odredjivanje hor i ver gradijenata
    [Hx,Hy]=gradient(prozor);
    Hx = Hx/sum(sum(abs(Hx)));
    Hy = Hy/sum(sum(abs(Hy)));
    
    Gx = imfilter(I, Hx, 'replicate', 'same');
    Gy = imfilter(I, Hy, 'replicate', 'same');
%     figure;imshow(Gx);title('Horizontalni gradijent');
%     figure;imshow(Gy);title('Vertikalni gradijent');
%odredjivanje magnitude gradijenta i ugla gradijenta
    Gm = (Gx.^2 + Gy.^2).^0.5;
    Ga = atan(Gy./Gx);
    Ga(Gx == 0) = 0; %ovaj uslov je zbog deljenja nulom
    Gm(Gm== 0)=0;
%     figure;imshow(Gm);title('Magnituda gradijenta');
%     figure;imshow(Ga);title('Ugao gradijenta');
%kvantizacija na pravce
    [M,N]=size(Ga);
    
    %krecemo se kroz celu matricu Ga koja predstavlja ugao gradijenta i 
    %vrsimo kvantizaciju svakog piksela pojedinacno na odredjeni
    %pravac
    for i=1:M
        for j=1:N
             if (Ga(i,j)>=-pi/8 && Ga(i,j)<pi/8)
                Ga(i,j)=0;
             end
            
             if (Ga(i,j)>=pi/8 && Ga(i,j)<3*pi/8)
                Ga(i,j)=pi/4;
             end
            
             if ((Ga(i,j)>=-pi/2 && Ga(i,j)<-3*pi/8) || (Ga(i,j)>=3*pi/8 && Ga(i,j)<=pi/2))
                Ga(i,j)=pi/2;
             end
            
             if (Ga(i,j)>=-3*pi/8 && Ga(i,j)<-pi/8)
                Ga(i,j)=-pi/4;
             end
        end
    end
    figure;imshow(Ga);title('Kvantizovani ugao gradijenta');
    Ga=Ga*360/(2*pi);  
    Gm1 = Gm; 
    %prosirujemo magnitudu gradijenta za jedan piksel sa svake strane 
    %kako bi mogli da se krecemo sa matricom 3x3 kroz celu sliku
    Gm1 = padarray(Gm, [1, 1], 'replicate');

     for i = 2:M+1
        for j = 2:N+1
            if (Ga(i-1,j-1) == 0)
                    P = Gm1(i-1:i+1,j-1:j+1).*[0 0 0;1 1 1;0 0 0];
            end;        
            if (Ga(i-1,j-1) == 45)              
                    P = Gm1(i-1:i+1,j-1:j+1).*[1 0 0;0 1 0;0 0 1];
            end;        
            if (Ga(i-1,j-1) == 90)                                        
                    P = Gm1(i-1:i+1,j-1:j+1).*[0 1 0;0 1 0;0 1 0];
            end;        
            if (Ga(i-1,j-1) == -45) 
                    P = Gm1(i-1:i+1,j-1:j+1).*[0 0 1;0 1 0;1 0 0];
            end;
            if(P(2,2)~=max(P(:)))
                   Gm(i-1,j-1) = 0;
            end;
        end
     end
     
%odredjivanje jakih i slabih ivica na osnovu pragova th i tl
    slabeIvice=zeros(M,N);
    jakeIvice=zeros(M,N);
    slabeIvice(Gm>=tl & Gm<th)=1;
    jakeIvice(Gm>=th)=1;

    figure;imshow(slabeIvice,[]);title('Slabe ivice');
    figure;imshow(jakeIvice,[]);title('Jake ivice');

%prolazak kroz mapu slabih ivica i trazimo piksele koji u svom susedstvu imaju
%makar jednu jaku ivicu. Prolazak vrsimo sve dok broj ivica ne ostane
%konstantan tokom cele iteracije
    
    jakeIviceP=zeros(M+2,N+2);
    slabeIviceP=zeros(M+2,N+2);
    jakeIviceP(2:M+1,2:N+1)=jakeIvice;
    slabeIviceP(2:M+1,2:N+1)=slabeIvice;
    
    susd=1;
    
    
     while susd
        susd=0;
        for i=2:M+1
            for j=2:N+1
                if (slabeIviceP(i,j)==1)
                    okolinaJake=jakeIviceP(i-1:i+1,j-1:j+1);
                     %za slucaj da u okolini piksela sa indeksom (i,j)
                     %nemamo uopste jake piksele suma okolinaJake matrice
                     %ce biti nula ,parametar susd nece postati 1 i 
                     %napusticemo while petlju
                     if (sum(sum(okolinaJake))~=0)
                        jakeIviceP(i,j)=1;
                        slabeIviceP(i,j)=0;
                        susd=1;
                     end
                end
                              
            end
        end
     end
    
     J=jakeIviceP(2:M+1,2:N+1);
     figure;imshow(J,[]);title('Rezultat Canny-jevog algoritma');


end










