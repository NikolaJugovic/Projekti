function [Sati, Minuti] =extract_time(I)

%Funkcija koja prima kao ulazni argument sliku sata u double formatu , a
%kao izlazni argument daje vreme pokazivanja sata


%ucitavanje slike i konvertovanje u gray 
Iref=im2double(rgb2gray(I));                      
[M,N]=size(Iref);
figure;imshow(Iref);title('Ulazna slika');
%Za detektovanje ivica slike koristimo gotovu funkciju edge i kanijev
%algoritam za detektovanje


%Ecircle=edge(I,'canny',0.2,4);      %ivice koje cemo koristiti za detekciju krugova

%Kako bi mogli da dobijemo informaciju o tome da li je pronadjena linija
%zapravo kazaljka koja nam je potrebna za odredjivanje vremena, potrebno je
%da najpre detektujemo centar casovnika, odnosno mesto gde se 'spajaju'
%kazaljke. Centar casovnika odredjujemo preko funkcije imfindcircles, a za detektovanje
%centra casovnika koristimo drugacije podesavajne edge funkcije.
%Kada detektujemo centar casovnika napravicemo matricu odredjenu velicinom 
%radijusa kruga i postaviti uslov da se tacka koja je bliza centru kruga mora
%nalaziti u opsegu ove matrice. Na ovaj nacin smo sigurni da smo lepo
%detektovali kazaljku i da nismo pokupili neku drugu detektovanu ivicu 


%Opseg pronalazenja radijusa kruga odredjujemo u zavistonsti od velicine
%same slike. Za velike vrednosti opsega vreme izvrsavanja funkcije koja
%pronalazi krug postaje visestruko vece
opKrug=[round(3*M/10),round(3*M/5)];

%low pass filtriranje za krugove, ovo radimo kako bi funkcija imfindcircles
%pronasla samo glavni krug (okvir casovnika)
lp=(lpfilter('gaussian',M,N,35)); 
                                    
If=fft2(Iref);
Ilp=If.*lp;
I=ifft2(Ilp); %filtrirana slika koju cemo koristiti za pronalazenje kruga


th=0.5; %Promenljiva koja predstavlja prag pronalazenja kruga , odnosno ova promenljiva
        %nam definise koliko ostar prelaz ivice mora biti kako bi se krug
        %uocio uopste. Za th -> 0 prelaz moze biti postepen i krug ce biti
        %detektovan, za th=1 prelaz mora biti izuzetno ostar
center=[];
radius=[];
%Petlja koja se vrti sve dok ne pronadje krug koji je nama potreban , uz to
%pri svakoj iteraciji smanjuje th sve dok se krug ne uoci. Za vece th
%funkcija imfindcircles radi brze , iz tog razloga krecemo od vrednosti
%th=0.5 , ukoliko ne pronadjemo krug smanjujemo vrednost za 60% pri svakoj
%iteraciji
while (isempty([center,radius]))
[center,radius] = imfindcircles(I,opKrug,'EdgeThreshold',th);
th=0.4*th;
%centar cemo koristiti za proveru validnosti kazaljki
end;

%ovim je krug odredjen i sa time smo zavrsili


%Ovde definisemo okolinu centra kruga koju cemo koristiti za proveru
%kazaljki
cenCh1=round((center(1)-radius/4):(center(1)+radius/4)); %okolina centra kruga
cenCh2=round((center(2)-radius/4):(center(2)+radius/4)); %okolina centra kruga

count=1;    %brojac za ogranicenje broja iteracija, kada count postane 5 a
            %jos uvek nismo nasli kazaljke izlazimo iz petlje i ispisujemo
            %poruku da funkcija nije uspela 

sigma=3;    %standardna devijacija gausovog filtra koju menjamo pri svakoj 
            %iteraciji dok ne pronadjemo kazaljke
while (1)

lp1=lpfilter('gaussian',M,N,22);
Ilp1=If.*lp1;
I=ifft2(Ilp1);


Eline=edge(I,'canny',0.8,sigma);       

%ovde je sve pravolinijski
[H, T, R] = hough(Eline,'Theta',-90:0.5:89);    %Hafova transformacija


P = houghpeaks(H,5,'Threshold',0.1*max(H(:)));
% figure; imagesc(H, 'XData',T,'YData',R)
% axis on, axis normal, hold on;
% plot(T(P(:,2)),R(P(:,1)),'s','color','white');

lines = houghlines(Eline,T,R,P);

duzine=zeros(1,length(lines));%niz u koji smestamo izracunate duzine svake 
                              %detektovane ivice
                              
% figure;imshow(I);title('Sve ivice');
% hold on
for k=1:length(lines)
    xy=[lines(k).point1;
        lines(k).point2];
%     plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','red');
    duzine(k)=(abs((lines(k).point2(2)-lines(k).point1(2))^2+(lines(k).point2(1)-lines(k).point1(1))^2))^0.5;
    
end;
% hold off

duzineMax=sort(duzine,'descend'); %sortiramo duzine detektovanih ivica po opadajucem poretku
MinIndex=find(duzineMax(1)==duzine); %odredjujemo indeks u listi na kom se nalazi minutara
SatIndex=find(duzineMax(2)==duzine); %odredjujemo indeks u listi na kom se nalazi satna kazljka   

Sati=0;
Minuti=0;
center=round(center);

%Pri pocetnom odredjivanju indeksa kazaljke za minute i sate
%pretpostavljamo da su prve tri najduze detektovane ivice upravo dve za
%kazaljku minuta i jednu za satnu kazaljku , ili kontra
if (lines(MinIndex).theta == lines(SatIndex).theta || abs(lines(MinIndex).theta - lines(SatIndex).theta) == 1  )
       MinIndex=(find(duzineMax(1)==duzine));
       SatIndex=(find(duzineMax(3)==duzine));
end;
%rastojanje od centra racunamo da bi posle imali informaciju o tome koju
%tacku tacno koristimoza proveru kvadranta
%Gledacemo da uvek point2 iz liste bude tacka koja je dalja od centra kruga(na neki nacin je intuintivnije).
%Tacku point1 cemo koristiti za proveru validnosti detektovanih ivica
d1m=(abs((lines(MinIndex).point1(2)-center(2))^2+(lines(MinIndex).point1(1)-center(1))^2))^0.5;  
d2m=(abs((lines(MinIndex).point2(2)-center(2))^2+(lines(MinIndex).point2(1)-center(1))^2))^0.5;
d1s=(abs((lines(SatIndex).point1(2)-center(2))^2+(lines(SatIndex).point1(1)-center(1))^2))^0.5;  
d2s=(abs((lines(SatIndex).point2(2)-center(2))^2+(lines(SatIndex).point2(1)-center(1))^2))^0.5;

%postavljanje point1 na poziciju blizu centru za obe kazaljke
if (d1m > d2m) 
    pom=lines(MinIndex).point2;
    lines(MinIndex).point2=lines(MinIndex).point1;
    lines(MinIndex).point1=pom;
end;
if (d1s > d2s) 
    pom=lines(SatIndex).point2;
    lines(SatIndex).point2=lines(SatIndex).point1;
    lines(SatIndex).point1=pom;
end;

%Posto smo sigurni da je point1 tacka bliza centru , nju cemo koristiti
%kao proveru za preklapanje kazaljki
%Proveravamo da li su kazaljke preklopljene, odnosno point1 kod obe
if (~((lines(SatIndex).point1(1) > cenCh1(1) && lines(SatIndex).point1(1) < cenCh1(length(cenCh1))) && (lines(SatIndex).point1(2) > cenCh2(1) && lines(SatIndex).point1(2) < cenCh2(length(cenCh2)))))
        %ovo znaci da nasa detektovana satna kazaljka zapravo nije satna
        %kazaljka vec neka ivica koja nas ne interesuje, odnosno prva pretpostavka 
        %koja nam pada na pamet je ta da su satna
        %kazaljka i minutara preklopljene 
        SatIndex=MinIndex;
        
end;   

xy1=[lines(SatIndex).point1;
        lines(SatIndex).point2];
xy2=[lines(MinIndex).point1;
        lines(MinIndex).point2];
% figure;imshow(I);title('Ivice od interesa');
% hold on
% 
%     plot(xy1(:,1),xy1(:,2),'LineWidth',2,'Color','red');
%  
%     plot(xy2(:,1),xy2(:,2),'LineWidth',2,'Color','red');
% 
% hold off

% x1m=lines(MinIndex).point1(1);
% y1m=lines(MinIndex).point1(2);
x2m=lines(MinIndex).point2(1);
y2m=lines(MinIndex).point2(2);
% x1s=lines(SatIndex).point1(1);
% y1s=lines(SatIndex).point1(2);
x2s=lines(SatIndex).point2(1);
y2s=lines(SatIndex).point2(2);
   
    

tm=lines(MinIndex).theta;
ts=lines(SatIndex).theta;
%konvertovanje stepeni u minute
if (tm >0)
    
    if (x2m>center(1) && y2m<center(2) )   %znaci da je kazaljka izmedju 12 i 3 
          Minuti=round(abs(tm)/6);
    end;
    if (x2m < center(1) && y2m > center(2))   %znaci da je kazaljka izmedju 6 i 9 
          Minuti=30+round(abs(tm)/6);
    end;                                
end;

if (tm <0)
    
    if (x2m < center(1) && y2m<center(2) )   %znaci da je kazaljka izmedju 9 i 12 
          Minuti=60-round(abs(tm)/6);                          
    end;
    if (x2m > center(1) && y2m > center(2) )   %znaci da je kazaljka izmedju 3 i 6 
          Minuti=30-round(abs(tm)/6);                          
    end;                                
end;
if (tm == 0 ) %znaci da pokazuje na 12 ili na 6
        if (y2m < center(2) )   %znaci da pokazuje na 12 
            Minuti=0;
        end;
        if (y2m > center(2))   %znaci da pokazuje na 6
            Minuti=30;
        end; 
end;
if (tm == -90) %znaci da pokazuje na 9 ili na 3
        if (x2m < center(1) )   %pokazuje na 9
            Minuti=45;
        end;
        if (x2m > center(1))    %pokazuje na 3
            Minuti=15;
        end; 
end;

%konvertovanje stepeni u sate
if (ts >0)
    
    if (x2s>center(1) && y2s<center(2) )   %znaci da je kazaljka izmedju 12 i 3 
          Sati=floor(abs(ts)/30);
          if (floor(abs(ts)/30)==0) 
              Sati=12;
          end;    
    end;
    if (x2s < center(1) && y2s > center(2))   %znaci da je kazaljka izmedju 6 i 9 
          Sati=6+floor(abs(ts)/30);
    end;                                
end;

if (ts <0)
    
    if (x2s < center(1) && y2s<center(2) )   %znaci da je kazaljka izmedju 9 i 12 
          Sati=12-ceil(abs(ts)/30);                          
    end;
    if (x2s > center(1) && y2s > center(2) )   %znaci da je kazaljka izmedju 3 i 6 
          Sati=6-ceil(abs(ts)/30);                          
    end;                                
end;
if (ts == 0 ) %znaci da pokazuje na 12 ili na 6
        if (y2s < center(2) )   %znaci da pokazuje na 12 
            Sati=12;
        end;
        if (y2s > center(2))   %znaci da pokazuje na 6
            Sati=6;
        end; 
end;
if (ts == -90) %znaci da pokazuje na 9 ili na 3
        if (x2s < center(1) )   %pokazuje na 9
            Sati=9;
        end;
        if (x2s > center(1))    %pokazuje na 3
            Sati=3;
        end; 
end;

if (((lines(SatIndex).point1(1) < cenCh1(1) || lines(SatIndex).point1(1) > cenCh1(length(cenCh1))) && (lines(SatIndex).point1(2) < cenCh2(1) || lines(SatIndex).point1(2) > cenCh2(length(cenCh2)))) && ((lines(MinIndex).point1(1) < cenCh1(1) || lines(MinIndex).point1(1) > cenCh1(length(cenCh1))) && (lines(MinIndex).point1(2) < cenCh2(1) || lines(MinIndex).point1(2) > cenCh2(length(cenCh2))))) 
%ovo znaci da su point1 minutare i satne kazaljke van , odnosno nismo
%detektovali kazaljke, iz tog razloga menjamo sigma i ulazimo ponovo u
%petlju
sigma=0.7*sigma;

end;
if (((lines(SatIndex).point1(1) > cenCh1(1) && lines(SatIndex).point1(1) < cenCh1(length(cenCh1))) && (lines(SatIndex).point1(2) > cenCh2(1) && lines(SatIndex).point1(2) < cenCh2(length(cenCh2)))) && ((lines(MinIndex).point1(1) > cenCh1(1) && lines(MinIndex).point1(1) < cenCh1(length(cenCh1))) && (lines(MinIndex).point1(2) > cenCh2(1) && lines(MinIndex).point1(2) < cenCh2(length(cenCh2)))))
%ovo znaci da smo menjanjem parametra sigma uspeli da izdvojimo validne
%satne i minutne kazaljke i napustamo while petlju
break;
end;
count =count+1;
if (count==5)
    break;
end;


end
fprintf('Vreme na satu je %i sati i %i minuta \n',Sati,Minuti);




