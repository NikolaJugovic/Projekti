 function [Plave Crvene]= extract_dice_score(I)
 %Funkcija koja kao ulazni argument prima sliku sa bacenim plavim i crvenim
 %kockicama, a vraca informaciju o zbiru plavih brojeva na kockicama i zbiru crvenih
 %brojeva
    
 
 
    I=(im2double(I));
    figure;imshow(I);title('Ulazna slika')

    Ir=I(:,:,1);
%Izdvajamo crvenu komponentu iz RGB formata slike. Koristeci crvenu
%komponentu detektovacemo broj plavih kruzica

    Ihsv=rgb2hsv(I);
%Iz hsv formata izdvajamo komponentu koja predstavlja zasicenje slike
%Pomocu ove komponente cemo odrediti ukupan broj detektovanih kruzica ,
%zatim oduzimamo broj plavih od ukupnog broja i dobijamo broj crvenih
    Isatb=Ihsv(:,:,2); 
%     figure;imshow(Isatb);title('Zasicenje');

%Radi lakseg detektovanja kruzica , povecavamo kontrast
    kr=imadjust(Ir,[0 120]/255,[0 1]);
    kb=imadjust(Isatb,[100 255]/255,[0 1]);

%     figure;imshow(kr);
    title('Crvena komponenta(brojimo plave)');

%     figure;imshow(kb);
    title('Zasicenje(brojimo ukupan broj kockica)');

    Er=edge(kr,'canny',0.7,2);
%     figure;imshow(Er);

    [centerR,radiusR]=imfindcircles(Er,[3 20],'Sensitivity',0.7);
    figure;imshow(I);title('Broj plavih');
    hold on
    viscircles(centerR, radiusR);
    hold off

    [centerB,radiusB]=imfindcircles(kb,[3  20],'Sensitivity',0.87);
    figure;imshow(I);title('Ukupan broj');
    hold on
    viscircles(centerB, radiusB);
    hold off

    Plave=length(radiusR);
    Crvene=length(radiusB)-Plave;
    fprintf('Broj plavih je %i ,broj crvenih je %i\n',Plave,Crvene);
    
 end