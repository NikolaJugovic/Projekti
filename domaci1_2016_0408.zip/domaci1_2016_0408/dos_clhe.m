function J = dos_clhe(I, bit_depth, limit)
%dos_chle
%Funkcija koja vrsi ekvalizaciju histograma uz ogranicenje kontrasta.
%Parametri funkcije :
%"I" Ulazna slika predstavljena kao 2D ili 3D matrica u formatu double
%iz opsega vrednosti [0, 1]
%
%"bit_depth" broj bita kojim se predstavljaju osvetljaji izlazne slike
%Izlazna slika moze imati najvise 2^(bit_depth) razlicitih osvetljaja slike
%
%"limit" parametar predstavlja ogranicenje maksimalnog elementa
%normalizovanog histograma i uzima vrednost iz opsega [0,1]
%
%J=dos_clhe(I,bit_depth) parametar limit uzima podrazumevanu vrednost 0.01
%
%J=dos_clhe(I) prametar bit_depth uzima podrazumevanu vrednost 8, dok
%parametar limit uzima podrazumevanu vrednost 0.01
%Pozivanje funkcije sa vise od 3 parametra ili manje od jednog parametra
%nije izvodljivo 
if (~isa(I,'double'))           %provera da li je matrica tipa double
   error('Matrica nije tipa double!');
else 
if (nargin == 1)                %za slucaj da imamo samo jedan ulazni parametar pretpostavicemo da je to slika
    bit_depth=8;
    limit=0.01;
else 
if (nargin ==2)                 %za slucaj da imamo 2 ulazna parametra pretpostavicemo da je to slika i bitDepth
    limit=0.01;
else 
if (nargin >3 || nargin <1)        %nepravilno pozivanje funkcije
    error('Broj ulaznih argumenata je manji od 1 ili veci od 3');
end;
end;
end;
end;
%prvo vrsimo proveru da li je ulazna slika 2D ili 3D, uz pretpostavku da za
%3D slucaj imamo najvise 3 komponente

[width ,height,dimenzija]=size(I);

%za slucaj da je slika u RGB formatu , vrsimo prelaz u HSV format i
%obradjujemo samo V na isti nacin kao sto obradjujemo gray sliku
if (dimenzija == 3) 
    
    H=rgb2hsv(I);
    I=H(:,:,3);

end;
        I=round(I.*(2^(bit_depth)-1));   %skaliranje ulazne slike na bit_deph rezoluciju
        var=I;                           %dobijamu sliku sa opsegom [0:2^(bit_depth)-1]   
                                         %koja je u double formatu
                                         %sledeci korak je ukljucivanje ogranicenja kontrasta limit
                                         %tako sto odsecamo sve vrednosti
                                         %normalizovanog histagrama koje prelaze
                                         %limit
       
       %racunamo histogram
        output = zeros(2^(bit_depth),1);


        % koristeci dve for petlje prolazimo kroz celu sliku i formiramo
        % histogram slike
         for i=1:width
            for j=1:height
                v = I(i, j)+1;
                output(v) = output(v) + 1;
            end
        end

        histnorm=output./(width*height);  %normalizujemo dati histogram
      
%odredjujemo "visak", odnosno broj piksela na normalizovanom histogramu
%kojih ima vise od limita odsecamo do limita i cuvamo deo koji je odsecen
        visak=0;   
        
        for i=1:(2^bit_depth)
            if (histnorm(i) > limit)
                visak=visak+histnorm(i)-limit;            
                histnorm(i)=limit;    
            end;
        end;
%Kada smo odredili odseceni deo histograma, ukupnu povrsinu koju smo odsekli
%rasporedjujemo na sve  pikse ponaosob. Ukoliko imamo visak piksela 
%(odnosno ako broj odsecenih piksela nije deljiv sa brojem osvetljaja na
%nasem histogramu ) piksele koji nam ostanu rasporedicemo nasumicno , sto
%nece previse uticati na izlaznu sliku.
        
         visak=round(visak*width*height);  %broj odsecenih piksela
        dodaj=floor(visak/(2^bit_depth));  %broj piksela koje cemo dodavati svakom ponaosob
        ostatak=visak-dodaj*(2^bit_depth);
         dodaj=dodaj/(height*width);        %broj piksela koje cemo dodavati svakom od osvetljaja ponaosob
         
    for i=1:(2^bit_depth)

            histnorm(i)=histnorm(i)+dodaj;

    end;
    
    
%Dodavanje ostatka koji se javio usled deljenja odsecenih piksela sa
%2^bitDepth-1 nije od prevelikog znacaja u odnosu na ostale piksele. 
%Ubacivannje tih piksela na ovaj nacin , preko rand funkcije , znacajno
%usporava kod za veliki broj bita. Iz tog razloga je to izbaceno
%odnosno zakomentarisano. Dobijena slika sa, i bez tih piksela je identicna. 
    

%------------------
%     randpix=round(rand(ostatak,1).*(2^bit_depth-1)); %formiramo random brojeve koji nam odredjuju kom osvetljaju
                                                    %dodeljujemo ostatak piksela 
%     ostatak=ostatak/((2^bit_depth)-1);
%     for i=1:(2^bit_depth)
%           if (i == randpix)
%               histnorm(i)=histnorm(i)+ostatak;
%           end;
%     end;
%--------------------

%sledeci korak koji radimo je trazenje kumulativne sume , za to cemo koristiti
%gotovu f-ju cumsum

cdf=cumsum(histnorm);
%Ekvalizacija histograma
lut = round(cdf*(2^bit_depth-1));
J = zeros(width,height);
    for i = 1:width
        for j = 1:height
            var(i,j) = I(i,j);
            if(var(i,j) == 2^bit_depth)
                var(i,j) = var(i,j) - 1;
            end; 
            J(i,j) = lut(var(i,j) + 1);
        end
    end
    
if (dimenzija==3)   %rgb slucaj
    H(:,:,3)=J;
    J=hsv2rgb(H);
end;    
    
    
J=J./(2^bit_depth-1);
  
end
    
    
        
    
        
        

        
    
    
    
    
   








    
    
    
    
        
        
        
        
        
        