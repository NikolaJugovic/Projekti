function [y] = dos_resample(x, up_down, r)

Ap=0.05;
Aa=70;
Wc=pi/r;
Bt=0.4*Wc;

h=lowpass_filter_kaiser(Wc,Bt,Aa,Ap); %formiranje LP filtra

Dh=length(h);
Dx=length(x);

if (strcmp(up_down,'false'))   %povecavanje ucestanosti odabiranja
    y=zeros(1,(r*Dx));
    for i = 0: Dx-1
        y(r*i +1)= x(i+1);
    end
    
    y=r*conv(y,h);  %konvolucija interpoliranog signala i LP filtra
    
    sred=floor(Dh/2)+1;  
    y=y(sred:r*Dx+sred-1);
    
elseif (strcmp(up_down, 'true')) %smanjivanje ucestanosti odabiranja
    z=conv(x,h);
    Dz=length(z);
    sred=floor(Dh/2)+1;
    z=z(sred:Dx+sred-1);
    y=zeros(1,floor(Dz/r));
    Dy=length(y);
    for i=0:Dy-1
        y(i+1)=z(r*i+1);
    end
end
end
    