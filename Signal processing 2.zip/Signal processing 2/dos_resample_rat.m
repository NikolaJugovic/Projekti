function [y]=dos_resample_rat(x,p,q)



if (p<=0 || q<=0)
    error('Pogresno zadati p i q');
end


pglob=p; %pretpostavka da je interpolacija u pitanju

if (q>p)      %slucaj kad je decimacija u pitanju
    pglob=q;
end

Aa=70;
Ap=0.05;
Wc=pi/pglob;
Bt=0.4*Wc;


h = lowpass_Parks_MekKlejn( Wc,Bt,Aa,Ap);%formiranje LP filtra

Dx=length(x);       %broj clanova ulaznog signala
Dh=length(h);       %broj clanova formiranog LP filtra

y1=zeros(1, p*Dx);
for i=0:Dx-1        
    y1(p*i+1)=x(i+1);
end

y2=p*conv(y1,h);   %LP filtriranje

sred=floor(Dh/2)+1;
y2=y2(sred:p*Dx+sred-1);
D2=length(y2);

y3=conv(y2,h);
y3=y3(sred:D2+sred-1);
D3=length(y3);
y=zeros(1,floor(D3/q));
D=length(y);
for i=0:D-1
    y(i+1)=y3(q*i+1);
end

end
















