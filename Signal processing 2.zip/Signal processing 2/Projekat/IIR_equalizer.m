function [y] = IIR_equalizer(x, fs, style)


%pojacanja u decibelima
ROCKdB=[ 5, 3.75, 3, 1.5, -0.5, -1.5, 1, 2.5, 3.75, 4.5];
POPdB=[ -1.5, -1, 0, 1.5, 4, 4, 2, 0, -1, -1.5 ];
DANCEdB=[ 4, 7, 5, 0, 2, 4, 5, 4.5, 3.5, 0]; 
CUSTOMdB=[0, -10, 20, 20, 30, 10, -20, 0,20, 0];  %pokvarivac pesme

%konverzija iz decibela u linearne vrednosti 
ROCK=10.^(ROCKdB/20);
POP=10.^(POPdB/20);
DANCE=10.^(DANCEdB/20);
CUSTOM=10.^(CUSTOMdB/20);

tipMuzike={'ROCK','POP','DANCE','CUSTOM'};

switch (find(ismember(tipMuzike,style)))
    case 1
        tip=ROCK;
    case 2
        tip=POP;
    case 3 
        tip=DANCE;
    case 4
        tip=CUSTOM;
        
end




Aa=60;
Ap=1;
 
% bandpass i highpass filtara

     
     [bVF,aVF]=highpass_filter(fs,15800,16000,Aa,Ap);
     [bPO,aPO]=bandpass_filter(fs,[7800 16200],[8000 16000],Aa,Ap);
 
 %prvo se formiraju NF filtri  
 
  % [bNF1,aNF1]=lowpass_filter(fs,16100,16000,Aa,Ap); %za filtar 9
  % [bNF2,aNF2]=lowpass_filter(fs,8100,8000,Aa,Ap);  %za filtar 8
  % [bNF3,aNF3]=lowpass_filter(fs,4100,4000,Aa,Ap);  %za filtar 7
  % [bNF4,aNF4]=lowpass_filter(fs,2100,2000,Aa,Ap);
  % [bNF5,aNF5]=lowpass_filter(fs,1100,1000,Aa,Ap);
  % [bNF6,aNF6]=lowpass_filter(fs,600,500,Aa,Ap);
  % [bNF7,aNF7]=lowpass_filter(fs,350,250,Aa,Ap);
  % [bNF8,aNF8]=lowpass_filter(fs,225,125,Aa,Ap);
  % [bNF9,aNF9]=lowpass_filter(fs,163,63,Aa,Ap);  %za filtar 1
   
 %filtriranje NF filtrom
 
    
 
 
   
   
   
  %  xhF=x*tip(10);
  %  x1NF=filter(bNF1,aNF1,x*tip(9));   %za filtar 9
  %  x2NF=filter(bNF2,aNF2,x*tip(8));   %za filtar 8
  %  x3NF=filter(bNF3,aNF3,x*tip(7));   %za filtar 7
  %  x4NF=filter(bNF4,aNF4,x*tip(6));   
  %  x5NF=filter(bNF5,aNF5,x*tip(5));
  %  x6NF=filter(bNF6,aNF6,x*tip(4));
  %  x7NF=filter(bNF7,aNF7,x*tip(3));   %za filtar 3
  %  x8NF=filter(bNF8,aNF8,x*tip(2));
  %  x9NF=filter(bNF9,aNF9,x*tip(1));   %za filtar 1
    
    
    
    
    
    
 %filtriranje sa highpass filtrom
 
    yhF=filter(bVF,aVF,x*tip(10));   %nije decimiran,ide kroz VF
    y1F=filter(bPO,aPO,x*tip(9));    %nije decimiran
    y2F=filter(bPO,aPO,dos_resample(x*tip(8),'true',2));
    y3F=filter(bPO,aPO,dos_resample(x*tip(7),'true',4));
    y4F=filter(bPO,aPO,dos_resample(x*tip(6),'true',8));
    y5F=filter(bPO,aPO,dos_resample(x*tip(5),'true',16));    
    y6F=filter(bPO,aPO,dos_resample(x*tip(4),'true',32));  %decimiran za 32
    y7F=filter(bPO,aPO,dos_resample(x*tip(3),'true',64));    %za 64
    y8F=filter(bPO,aPO,dos_resample(x*tip(2),'true',128));    %za 128
    y9F=filter(bPO,aPO,dos_resample(x*tip(1),'true',256));
    
 %interpolacija filtriranih izlaza
    
    Yh=yhF;     %jer nije decimiran
    Y1=y1F;      %jer nije decimiran
    Y2=dos_resample(y2F,'false',2);
    Y3=dos_resample(y3F,'false',4);
    Y4=dos_resample(y4F,'false',8);
    Y5=dos_resample(y5F,'false',16);
    Y6=dos_resample(y6F,'false',32);
    Y7=dos_resample(y7F,'false',64);
    Y8=dos_resample(y8F,'false',128);
    Y9=dos_resample(y9F,'false',256);     
   
  
   %skracivanje izlaza koji su decimirani sa velikim vrednostima pa 
   %interpolirani
   niz=[length(Yh) length(Y1) length(Y2) length(Y3) length(Y4) length(Y5) length(Y6) length(Y7) length(Y8) length(Y9)];
   
   minLen=min(niz);
   %izgubice se nekoliko clanova niza na ovaj nacin ali ne predstavlja neki
   %znacajan problem za rad samog ekvilizatora
  
   
   Yh=Yh(1:minLen); 
   Y1=Y1(1:minLen);
   Y2=Y2(1:minLen);
   Y3=Y3(1:minLen);
   Y4=Y4(1:minLen);
   Y5=Y5(1:minLen);
   Y6=Y6(1:minLen);
   Y7=Y7(1:minLen);
   Y8=Y8(1:minLen);
   Y9=Y9(1:minLen);
   
    
    
    
    
  %sabiranje svih izlaza
  
  
   y=(Yh+Y1+Y2+Y3+Y4+Y5+Y6+Y7+Y8+Y9);   %vrednost koja funkcija vraca

end
