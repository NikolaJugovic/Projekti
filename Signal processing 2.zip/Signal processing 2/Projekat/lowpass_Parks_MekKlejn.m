function [y] = lowpass_Parks_MekKlejn( Wc,Bt,Aa,Ap)

deltaP=( 10^(0.05*Ap)-1 )/( 10^(0.05*Ap)+1 );
deltaA = 10^(-0.05*Aa);
Wp=Wc-Bt/2;
Wa=Wc+Bt/2;

Nfreqz=25000;

plotuj=1;
%racunanje reda filtra

%D asimptotsko
D = (0.005309*(log10(deltaP))^2+0.07114*log10(deltaP)-0.4761)*log10(deltaA)-(0.00266*(log10(deltaP))^2+0.5941*log10(deltaP)+0.4278);

f = 11.01217+0.51244*(log10(deltaP)-log10(deltaA));

M = 2*pi*D/Bt-f*Bt/(2*pi) + 1;
M = ceil(M);		% broj clanova impulsnog odziva
N = M-1;			% red filtra



FaN = Wa/pi;
FpN = Wp/pi;	% normalizacija ucestanosti 

Hd = [1   1    0   0];	
F = [ 0 FpN FaN  1];	% vektor normalizovanih ucestanosti
y = firpm(N,F,Hd);	   %formiranje Parks Meklejnovof filtra


[H,w] = freqz(y,1,Nfreqz); %frekvencijski odziv digitalnog filtra
Hfa = abs(H);    %amplitudska karakteristika filtra
Hfp = unwrap(angle(H));  %fazna karakteristika filtra uz korekciju


indeksProp = ceil((Nfreqz*Wp)/(pi))+1; %element u nizu od kog krece propusni ospeg
indeksNeprop = floor((Nfreqz*Wa)/(pi))+1;     %element u nizu od kog krece nepropusni opseg
Ha = Hfa(indeksNeprop:end);
Hp = Hfa(1:indeksProp);

if((max(Ha)<= deltaA) && (min(Hp) >= deltaP ))
    disp('Gabariti su zadovoljeni');
else
    while(1)
        N=N+1;
        M=M+1;
        y = firpm(N,F,Hd);    %formiranje novog filtra sa drugim parametrima
        %za slucaj da gabariti nisu zadovoljeni
        [H,w]=freqz(y,1,Nfreqz); 
        Hfa=abs(H);
        Ha = Hfa(indeksNeprop:end);
        Hp = Hfa(1:indeksProp);
        if((max(Ha) <= deltaA) && (min(Hp) >= deltaP ))
            break;
        end
    end

end

niz = 0 : length(y)-1;

if(plotuj == 1) 
    
    figure(34)
        subplot(211)
        stem(niz,y),title('Impulsni odziv')
        subplot(212)
        plot(w,Hfa),title('Amplitudska karakteristika')
        xlabel('Relativna kruzna ucestanost ');
        ylabel('|H(z)|');
    figure(35)    
        subplot(211)
        plot(w,20*log10(Hfa)),title('Amplitudska karakteristika u dB')
        xlabel('Relativna kruzna ucestanost');
        ylabel('|H(z)| dB');
        subplot(212)
        plot(w,Hfp),title('Fazna karakteristika')
        xlabel('Relativna kruzna ucestanost');
        ylabel('|H(z)| dB');
end

end




