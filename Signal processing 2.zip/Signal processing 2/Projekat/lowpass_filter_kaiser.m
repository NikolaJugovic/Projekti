function [h] = lowpass_filter_kaiser(Wc, Bt, Aa, Ap)

 
 

if ((Wc > pi) || (Bt > pi) || (Wc < 0) || (Bt < 0))
    error('Pogresni podaci za FIR filtar');
end

if (Ap > Aa)
    error ('Vece slabljenje u propusnom od nepropusnog')
end
 
Wp=Wc-Bt/2;
Wa=Wc+Bt/2;

deltaA = 10^(-0.05*Aa);
deltaP = (10^(0.05*Ap) - 1) / (10^(0.05*Ap) + 1);

ApGlob=Ap;
AaGlob=Aa;
ApPrivr=Ap;
AaPrivr=Aa;


while(1)
    deltaAprivr= 10^(-0.05*Aa);
    deltaPprivr = (10^(0.05*Ap) - 1) / (10^(0.05*Ap) + 1);
    
    %racunanje delta po formuli
    delta = min(deltaPprivr, deltaAprivr);
    if (delta ~= deltaAprivr);
        AaPrivr = -20*log10(delta);
    end
    
    %racunanje beta po formuli
    beta=0;    % polazimo od slucaja da je Aa manje od 21dB
    
     if((AaPrivr >= 21) && (AaPrivr <=50))
        beta = 0.5842*(AaPrivr - 21) ^ 0.4 + 0.07886*(AaPrivr - 21);
    elseif (AaPrivr > 50)
        beta = 0.1102*(AaPrivr - 8.7);
     end
    
     %racunanje M
     D = 0.9222;   % opet polazimo od slucaja da je Aa manje ili jednako od 21dB
    if (AaPrivr > 21)
        D=(AaPrivr-7.95)/14.36; 
    end
    M = ceil(2*pi*D/Bt+1); % broj clanova impulsnog odziva prozorske funkcije
    N = M-1;               % red filtra    
    
    
    %kajzerova prozorska funckija
    w=kaiser(M,beta)';
    
    %impulsni odziv idealnog LP filtra
    n = -(M-1)/2:(M-1)/2;
    h = sin(n*Wc)./(n*pi);
    
    if (mod(M,2) == 1)
        h((M+1)/2)=Wc/pi;
        
    end
    
    h=h.*w;     %mnozenje iffta idealnog filtra sa prozorskom funkcijom
    
    %Digitalni filtar
    
    Nfreqz = 2^14; %
    H = fft(h,Nfreqz);
    Hfa = abs(H(1:floor(Nfreqz/2)));
    
    %podesavanje gabarita filtra------------------------------
    propusni=0;
    nepropusni=0;   %polazak od pretpostavke  da su oba opsega losa
    
    dw=(2*pi)/Nfreqz;
    ia = floor(Wa/dw);  %indeks nepropusnog opsega
    ip = ceil(Wp/dw);   %indeks propusnog opsega
    
    Ha = Hfa(ia:floor(Nfreqz/2));   %amplitudska karakteristika nepropusnog opsega
    Hp = Hfa(1:ip);  %amplitudska karakteristika propusnog opsega
    
   % maxbs = max(20*log10(Ha)); 
   % minbp = min(20*log10(Hp));
    
    if ((max(20*log10(Ha)) > -Ap) || (ApPrivr <= 0)) %provera da li ampl.k-ka 
        %filtra zadvoljava zadate gabarite
        
        AaGlob= AaGlob - 0.01*Aa;   %smanjivanje globalne granice za 1%
        AaPrivr=AaGlob;         
        ApPrivr=Ap;
        
    end
    
    if (AaGlob < 0.5*Aa)
        
        error('Prestrogi gabariti');
    end
    
    if (max(20*log10(Ha)) > -AaGlob)
        AaPrivr = AaPrivr + 0.001*Aa;
    else
        nepropusni=1;
    end
    
    if (min(20*log10(Hp)) < -Ap)
        if (ApPrivr > 0.01*Ap)
            ApPrivr = ApPrivr -0.01*Ap;
        end
    else
        propusni=1;
    end
    if (propusni ==1 && nepropusni ==1 )
        break
    end
end


%odkomentarisati za plotovanje filtra

% %-------------------PROVERA------------------
%         w = (0:length(Hfa)-1)*2*pi/Nfreqz;
%         Wend = pi;
%        deltaAGlob = 10^(-0.05*AaGlob);
%        deltaPGlob = (10^(0.05*ApGlob) - 1) / (10^(0.05*ApGlob + 1));
% %---Amplitudska karakteristika digitalnog filtra u linearnoj razmeri
%             figure;
%          
%             subplot(3,1,1);
%          
%             plot(w,Hfa, 'LineWidth', 2);
%             grid on
%             title('Amplitudska karakteristika u linearnoj razmeri');
%             xlabel('Kruzna ucestanost (Hz)');
%             ylabel('|H(z)|');
% 
%         % crtanje DATIH gabarita\
%         hold on
%             x_1_g = [Wa Wend];    y_1_g = [deltaAGlob deltaAGlob];
%             x_1 = [Wa Wend];      y_1 = [deltaA deltaA];
%             x_2 = [Wa Wa];	y_2 = [deltaA 1-deltaP];
%             
%             x_3 = [0  Wp];	y_3 = [1-deltaP 1-deltaP];
%             x_4 = [Wp Wp];	y_4= [deltaA 1-deltaP];
%             
%         % crtanje POOSTRENIH gabarita
%            deltaA = 10^(-0.05*AaPrivr);
%            deltaP = 1 - 10^(-0.05*ApPrivr);
%             
%             x_1v = [Wa Wend];      y_1v = [deltaA deltaA];
%             x_2v = [Wa Wa];	y_2v = [deltaA 10^(-0.05*Aa)];
%             
%             x_3v = [0  Wp];	y_3v = [1-deltaP 1-deltaP];
%             x_4v = [Wp Wp];	y_4v= [10^(-0.05*Ap) 1-deltaP];
%             
%             % crvene - gabariti koji su prosledjeni funkciji
%             % zelena - poostreni gabariti
%             % magenta(ljubicasta) - slabljenje koje smo promenili da bi
%             %               napravili filtar iako su previse ostri gabariti
%             plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,...
%                 'r','LineWidth',1.5);
%             plot(x_1v,y_1v,':g',x_2v,y_2v,':g',x_3v,y_3v,':g',...
%                 x_4v,y_4v,'LineWidth',1.5);
%             plot(x_1_g,y_1_g,'m');
%         hold off
%             
% %---Amplitudska karakteristika digitalnog filtra u logaritamskoj razmeri
%          
%          
%          
%             subplot(3,1,2);
%          
%             plot(w,20*log10(Hfa), 'LineWidth', 2);
%             grid on
%             title('Amplitudska karakteristika u logaritamskoj razmeri');
%             xlabel('Kruzna ucestanost (Hz)');
%             ylabel('|H(z)| dB');
% 
%         hold on
%         % crtanje DATIH gabarita
% 
%             x_1_g = [Wa Wend];    y_1_g = [-AaGlob -AaGlob];
%             x_1 = [Wa Wend];    y_1 = [-Aa -Aa];
%             x_2 = [Wa Wa];      y_2 = [-Aa -Ap];
% 
%             x_3 = [ 0 Wp];      y_3 = [-Ap -Ap];
%             x_4 = [Wp Wp];      y_4 = [-Aa -Ap];
%         % crtanje POOSTRENIH gabarita
%             x_1v = [Wa Wend];       y_1v = [-AaPrivr -AaPrivr];
%             x_2v = [Wa Wa];      y_2v = [-Aa -AaPrivr];
% 
%             x_3v = [ 0 Wp]; 	y_3v = [-ApPrivr -ApPrivr];
%             x_4v = [Wp Wp];      y_4v = [-Ap -ApPrivr];
%             
%             % crvene - gabariti koji su prosledjeni funkciji
%             % zelena - poostreni gabariti
%             % magenta(ljubicasta) - slabljenje koje smo promenili da bi
%             %               napravili filtar iako su previse ostri gabariti
%             plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,...
%                 'r','LineWidth',1.5);
%             plot(x_1v,y_1v,':g',x_2v,y_2v,':g',x_3v,y_3v,':g',...
%                 x_4v,y_4v,'LineWidth',1.5);
%             plot(x_1_g,y_1_g,'m');
%         hold off
% 
% %---Amplitudska karakteristika pomocu semilogx
%         
%             subplot(3,1,3);
%         
%             semilogx(w,20*log10(Hfa), 'LineWidth', 2);
%             grid on
%             title('Amplitudska karakteristika semilogx');
%             xlabel('Kruzna ucestanost (Hz)');
%             ylabel('|H(z)| dB');
% 
%             %crtanje DATIH gabarita
%         hold on
% 
%             x_1_g = [Wa Wend];        y_1_g = [-AaGlob -AaGlob];
%             x_1 = [Wa Wend];          y_1 = [-Aa -Aa];
%             x_2 = [Wa Wa];            y_2 = [-Aa -Ap];
%     
%             x_3 = [Wp*1e-1 Wp];        y_3 = [-Ap -Ap];
%             x_4 = [Wp Wp];            y_4 = [-Aa -Ap];
%         % crtanje POOSTRENIH gabarita
%             x_1v = [Wa Wend];          y_1v = [-AaPrivr -AaPrivr];
%             x_2v = [Wa Wa];            y_2v = [-AaPrivr -Aa];
% 
%             x_3v = [Wp*1e-1 Wp];        y_3v = [-ApPrivr -ApPrivr];
%             x_4v = [Wp Wp];             y_4v = [-Ap -ApPrivr];
%             
%             % crvene - gabariti koji su prosledjeni funkciji
%             % zelena - poostreni gabariti
%             % magenta(ljubicasta) - slabljenje koje smo promenili da bi
%             %               napravili filtar iako su previse ostri gabariti
%             plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,...
%                 'r','LineWidth',1.5);
%             plot(x_1v,y_1v,':g',x_2v,y_2v,':g',x_3v,y_3v,':g',...
%                 x_4v,y_4v,'LineWidth',1.5);
%             plot(x_1_g,y_1_g,'m');
%         hold off
% end
       
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    