%%
%-----------------------Deo 1.4 ----------------------------

%impulsni odziv ekvalizatora

%kreiranje diraka

t=0:0.01:100;

x=zeros(1,length(t));
x(1)=1;


%impulsni CUSTOM ekv
yImpC=IIR_equalizer(x,44100,'CUSTOM');

figure(10);
subplot(411);
plot(t(1:length(yImpC)),yImpC);
title('impulsni odziv ekvilajzera za CUSTOM,ROCK,POP i DANCE tip');
% xlabel('time[s]');



%impulsni ROK ekv
yImpR=IIR_equalizer(x,44100,'ROCK');
subplot(412);
plot(t(1:length(yImpR)),yImpR);
% title('impulsni odziv ekvilajzera za ROCK tip');
% xlabel('time[s]');


%impulsni POP ekv
yImpP=IIR_equalizer(x,44100,'POP');
subplot(413);
plot(t(1:length(yImpP)),yImpP');
% %title('impulsni odziv ekvilajzera za POP tip');
% xlabel('time[s]');



%impulsni DANCE ekv
yImpD=IIR_equalizer(x,44100,'DANCE');
subplot(414);
plot(t(1:length(yImpD)),yImpD');
% title('impulsni odziv ekvilajzera za DANCE tip');
xlabel('time[s]');


%%

%--------------------------Deo1.5----------------------


%frekvencijska karakteristika impulsnog odziva ekvalizatora i odredjivanje
%dft-a


%dft impulsnih  odziva razlicitih tipova muzike

yImpCf=fft(yImpC,20000);
yImpRf=fft(yImpR,20000);
yImpPf=fft(yImpP,20000);
yImpDf=fft(yImpD,20000);



%crtanje frekvencijskih karakteristika impulsnih odziva

fs=44100;
df=fs/length(yImpCf);



%za CUSTOM(u skladu sa menjanjem  parametara u funkciji IIR_equalization 
%menjaju se i grafici amplitude i faze , tako da je funkcija IIR dobra)


figure(23)
subplot(211);
semilogx(df:df:fs/2,20*log10(abs(yImpCf(1:floor(length(yImpCf))/2))));
title('Amplitudska karakteristika impulsnog odziva za CUSTOM');
xlabel('f[Hz]');
grid on;
subplot(212);
semilogx(df:df:fs/2,angle(yImpCf(1:floor(length(yImpCf)/2))));
title('Fazna karakteristika impulsnog odziva za CUSTOM');
xlabel('f[Hz]');
grid on;



%za DANCE

figure(24)
subplot(211);
semilogx(df:df:fs/2,20*log10(abs(yImpDf(1:floor(length(yImpDf))/2))));
title('Amplitudska karakteristika impulsnog odziva za DANCE');
xlabel('f[Hz]');
grid on;
subplot(212);
semilogx(df:df:fs/2,angle(yImpDf(1:floor(length(yImpDf)/2))));
title('Fazna karakteristika impulsnog odziva za DANCE');
xlabel('f[Hz]');
grid on;



%za POP
figure(25)
subplot(211);
semilogx(df:df:fs/2,20*log10(abs(yImpPf(1:floor(length(yImpPf))/2))));
title('Amplitudska karakteristika impulsnog odziva za POP');
grid on;
subplot(212);
semilogx(df:df:fs/2,angle(yImpPf(1:floor(length(yImpPf)/2))));
title('Fazna karakteristika impulsnog odziva za POP');
xlabel('f[Hz]');
grid on;

%za ROCK
figure(26)
subplot(211);
semilogx(df:df:fs/2,20*log10(abs(yImpRf(1:floor(length(yImpRf))/2))));
title('Amplitudska karakteristika impulsnog odziva za ROCK');
grid on;
subplot(212);
semilogx(df:df:fs/2,angle(yImpRf(1:floor(length(yImpRf)/2))));
title('Fazna karakteristika impulsnog odziva za ROCK');
xlabel('f[Hz]');
grid on;

%%
%----------------------Deo1.6  -------------------------

%ucitavanje pesme i snimanje u equliazed sound 

fss=44100;
[kendi, fss]=audioread('Kendi - Limun & Lajm (OFFICIAL VIDEO).mp3');
kend=kendi(2500000:length(kendi));
kendiEq=IIR_equalizer(kend,44100,'ROCK'); %primetice se vrlo mala promena 

audiowrite('equalized_sound.wav',kendiEq,44100);



