function [b, a] = highpass_filter(fs, fa, fp, Aa, Ap) 

if (fa > fp) 
    error ('nepravilno uneti parametri');
end


%pojacanje u propusnom i slabljenje u nepropusnom koje ce se menjati u
%petlji
Aapomocno=Aa;
Appomocno=Ap;
Apglobalno=Ap;   %ono je za promenu ulaznih parametara ukoliko ne moze bas nikako da
                    %se formira filtar sa zadatim parametrima


%broj tacaka za freqz funkciju
Nfreqz = 10000;


%predistorzija za blinearnu transformaciju
wpPredist = 2*fs*tan(fp*2*pi/fs/2);
waPredist = 2*fs*tan(fa*2*pi/fs/2);
% wpPredist=fp*2*pi;
% waPredist=fa*2*pi;





%normalizacija
% wpN=1;
% waN=(wa2Predist^2-w0^2)/(wa2Predist*B);

wpN = 1;
 a = wpN / wpPredist;
 waN = a * waPredist;

while(1)
    k=sqrt(1-(waN/wpN)^2);
    D=(10^(0.1*Aapomocno)-1)/(10^(0.1*Appomocno)-1);
    q0=(1/2)*((1-sqrt(k))/(1+sqrt(k)));
    q=q0+2*q0^5+15*q0^9+15*q0^13;
    red=ceil(real(log10(16*D))/real(log10(1/q)));
    if red==0
        red=1;
    end
    
    [z,p,kp]=ellipap(red,Appomocno,Aapomocno);
    brojilac=kp*poly(z);
    imenilac=poly(p);

    %Transformacija normalizovanog prototipa u PO
    
    [numa,dena]=lp2hp(brojilac,imenilac,wpPredist);       
    
    %diskretizacija
    [numd,dend]=bilinear(numa,dena,fs);
    
  
    
    
    %formiranje funkcije prenosa filtra
    [hd,Wd]=freqz(numd,dend,Nfreqz);
    Hd=abs(hd);
%     fd=(Wd*fs)/(2*pi);

    %provera gabarita
    NOOK = 0;
    POOK = 0;
    df=(fs/2)/Nfreqz;

    ia=ceil(fa/df)+1;
    ip=floor(fp/df)+1;
    
    Ha=Hd(1:ia);   %Amplitudska Karakteristika Nepropusnog Opsega
    Hp=Hd(ip:end);   %Amplitudska Karakteristika Propusnog Opsega
    
    
    if(max(20*log10(Ha))>-Aa)
        Aapomocno=Aapomocno+Aapomocno*0.1;
    else
        NOOK=1;
    end
    
    if(min(20*log10(Hp))<-Ap)
        Appomocno=Appomocno-Appomocno*0.1;
    else
        POOK=1;
    end   
    if((NOOK==1)&&(POOK==1))
        
        break
    end
    
end


b=numd;
a=dend;


  end
