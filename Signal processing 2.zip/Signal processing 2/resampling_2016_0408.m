clear all
close all
clc

N = 200;
n = 0:N-1;
fs = 44100;    %frekvencija odabiranja
xul = sin(1.3*n*2*pi) + sin(0.8*n*2*pi) + sin(0.3*n*2*pi);
t=n/fs;   %niz [0:199] podeljen sa frekvencijom odabiranja

p=7;
q=4;


if (p<q)
yq = dos_resample_rat(xul,p,q);  %decimiran signal
                          
tq = [0:length(yq)-1] / (p/q*fs);  %niz po kome se plotuje decimiran signal       
figure (20)
    
stem(t,xul);     
hold on;
    
stem(tq,yq);  
title('p=4 q=7');

    

else 
yp = dos_resample_rat(xul,p,q);   %interpoliran signal
tp = [0:length(yp)-1] / (p/q*fs);
figure(21)

stem(t,xul);
hold on

stem(tp,yp);
title('p=7 q=4');

end            
            
            
            