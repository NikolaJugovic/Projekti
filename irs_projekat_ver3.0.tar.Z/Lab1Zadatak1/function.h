

#ifndef FUNCTION_H_
#define FUNCTION_H_

extern void led_diode();

#endif /* FUNCTION_H_ */

