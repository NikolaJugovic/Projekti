function J=dos_non_local_means(I, K, S, var, h)
%Funkcija koja vrsi ne-lokalno usrednjavanje, i filtrira
%2D gray-scale sliku.Kvalitet filtrirane skike zavisi od 
%prosledjenih paramaetara K, S,var,i h
%I-Ulazna slika koju treba isfiltrirati, predstavljena u double formatu
%K-Velicina prozora nad kojim se proverava strukturalna slicnost
%S-Velicina prozora u okviru kog se pretrazuju kandidati za usrednjavanje
%var-Procenjena varijansa slike
%h-jacina odsumljivanja

if (~isa(I,'double'))           %provera da li je matrica tipa double
   error('Ulazna slika mora biti tipa double!');
end;
%najpre proveravamo broj ulaznih elementara i u zavisnosti od toga
%odredjujemo elemente koji ce biti postavljeni po defaultu
if (nargin == 1)
    K=3;
    S=15;
    var=0.0078;
    h=0.05;
else 
if (nargin == 2)
    S=15;
    var=0.0078;
    h=0.05;
else 
if (nargin == 3)
    
    var=0.0078;
    h=0.05;
else
if (nargin == 4)
    
    h=0.05;
else
if (nargin > 5 || nargin <1)
    error('Broj ulaznih elemenata nije odgovarajuci');
end;
end;
end;
end;
end;

%sledeca stvar o kojoj treba brinuti jesu ulazne promenljive K i S, da bi
%blokovi bili simetricni oko jednog piksela moramo zahtevati da ove
%promenljive budu neparne
%Za slucaj da su unete parne promenljive lako vrsimo njihovo pretvaranje u
%neparne 

S = S + mod(S+1,2);
K = K + mod(K+1,2);

%Sledece sto nam je potrebno jeste prosirenje ulazne slike/matrice . 
%Prosirenje vrsimo u zavisnosti od parametara S i K na sledeci nacin

pros=(K+S)/2-1;
Q=padarray(I,[pros, pros],'symmetric','both');
[M,N]=size(Q);
%Parametar symmetric znaci da ce se ulazna slika prosiriti u zavisnotti od
%ulazne slike ,odnosno bice simetricna u odnosu na ivicu ulazne slike]
%Parametar both znaci da ce to prosirenje biti izvrseno sa svake strane
%ulazne slike

K1=(K-1)/2;
S1=(S-1)/2;

for i=(pros+1):(M-pros)
    for j=(pros+1):(N-pros)

%Pomocu ove dve for petlje obilazimo celu sliku(neprosireni deo) jedan po
%jedan piksel 
%Formiramo matricu koju cemo koristiti za racunanje w matrice. w matricu kasnije
%koristimo za izracunavanje srednje vrednosti po definiciji
    wPomocno=0;   
    
    %Sada formiramo dve for petlje pomocu koje cemo se kretati kroz matricu
    %velicine KxK sa okolinom SxS
    %Pri svakoj iteraciji izdvajamo matricu velicne SxS iz ulazne matrice Q
    %Od svake izdvojene matrice SxS oduzimamo centrirani piksel te iste SxS matrice
    %i kvadriramo dobijeni rezultat. Ovakvih iteracija kao sto je vec
    %pomenuto imamo KxK. Na ovaj nacin smo obisli matricu velicine
    %(S+K-1)x(S+K-1) u blokovima velicine SxS , izvrsili gore pomenute
    %operacije, i rezultate sumirali u wPomocno KxK puta.
    %wPomocno ce biti velicine SxS
   
    %   Q((i - pros + k - 1 : i - pros + S + k - 2), (j - pros + l - 1 : j - pros + S + l - 2))     clan kojim izdvajamo matricu velicine SxS iz Q matrice    
    %   Q(i-K1+k-1,j-K1+l-1))  clan kojim dobijamo centrirani piksel u matrici velicine SxS
    for k=1:K
        for l=1:K
            wPomocno = wPomocno + (Q((i - pros + k - 1 : i - pros + S + k - 2), (j - pros + l - 1 : j - pros + S + l - 2)) - Q(i-K1+k-1,j-K1+l-1)).^2;
            
        end;
    end;    
    
    
    
    %Kada smo izracunali wPomocno racunamo tezinsku funkciju po definiciji
   
    w = exp(-max(wPomocno/(K^2) - (2*var),0)/(h^2)); 
    
    %Po definiciji sa predavanja
    J(i,j) = sum(sum(Q((i-S1:i+S1),(j-S1):(j+S1)) .* w))./sum(w(:));
        
        
    end;
    
end;

J = J((pros + 1 : M-pros),(pros + 1 : N-pros)); 

end











    
    
