clear all;
close all;
clc;


%%
%-----------------DEO 1---------------------

f=imread('../sekvence/girl_ht.tif');        %ucitavanje slike
f=im2double(f);
figure;imshow(f);        %plotovanje slike
title('Ulazna slika');


[M,N]=size(f);
%da ne bi doslo do greske usled cirkularnosti konvolucije , ulaznu sliku
%prosirujemo nulama

M1=round(M/2);
N1=round(N/2);  

f=padarray(f,round([M/2,N/2]),'both');
  
figure;imshow(f);

[P,Q]=size(f);                  %odredjivanje dimenzija slike prosirene
                                %slike
F=fft2(f);                      %odredjivanje furijeove transformacije slike

figure;imshow(log(1+abs(fftshift(F))),[]);

Hlp=lpfilter('gaussian',P,Q,120);   %formiranje low pass filtra 
                                    %koji ce ukloniti sve informacije o
                                    %slici koje nam nisu previse potrebne, i 
                                    %koji ce ukloniti veliku kolicinu suma
                                    %U sustini low pass filtar ce ublaziti
                                    %ostre prelaze i na taj nacin smanjiti
                                    %uocljivost tackica , ali ce takodje i
                                    %zamutiti samu sliku. Iz ovog razloga
                                    %moramo naci kompromis izmedju
                                    %uklanjanja tackica i zamucivanja slike
                                                                   
                                    
Glp=Hlp.*F;                                     %mnozenjem u frekv domenu filtriramo ulaznu sliku
figure;imshow(log(1+abs(fftshift(Glp))),[]);    %spektar slike posle low pass filtriranja

glp=ifft2(Glp);                                 %slika posle low pass filtriranja
                                                %pomocna slika za dalju obradu        
glp=glp((M1+1):(P-M1),(N1+1):(Q-N1));           %kropovana slika posle low pass filtriranja
figure;imshow(glp);
title('Ulazna slika posle LP filtriranja');


%sledece sto radimo je filtriranje pomocu renotch filtra koji ce odseci
%delove spektra koji se nalaze oko DC komponente i koji nisu previse
%znaccajni za sam izgled slike. Renotch filtar ce biti formiran tako da ne
%ukloni DC komponentu i na taj nacin narusi izgled slike

H1=recnotch('reject','both',P,Q,15,50,50);       %formiranje renotch filtra
GlpR=Glp.*H1;                                   %filtriranje pomocu renotch filtra
figure;imshow(log(1+abs(fftshift(GlpR))),[]);    %spektar slike posle low pass filtriranja i renotch filtriranja
gLpR=ifft2(GlpR);
gLpR=gLpR((M1+1):(P-M1),(N1+1):(Q-N1));

figure;imshow(gLpR);                                
title('Slika posle low pass i renotch filtriranja');



%Sledece je filtriranje pomocy notch filtra 
%Prvo sto radimo je pronalazenje koordinata spektra koje zelimo da isfiltriramo,
%to odredjujemo eksperimentalno

C1=[759 2480;906 2480;1052 2480;];
C2=[906 2785;1052 2785;1205 2785;1352 2785;1502 2785;];

C=[C1 ;C2];
  
H=cnotch('gaussian','reject',P,Q,C,40);     %formiranje filtra

G=GlpR.*H;                                   %filtriranje slike

figure;imshow(log(1+abs(fftshift(G))),[]);
title('Spektar slike nakon low pass, renotch i notch filtriranja');

g=ifft2(G);
g=g((M1+1):(P-M1),(N1+1):(Q-N1));

figure;imshow(g);
title('Filtrirana slika');

%Nakon svog filtriranja pozljno je blago razvlacenje kontrasta slike radi
%boljeg izgleda

g=double(g/(max(max(g))));              %skaliranje filtrirane slike 

gk=imadjust(g,[0.2 1],[0 1]);              %razvlacenje kontrasta

figure;imshow(gk);
title('Konacna izlazna slika');


%%
%-------------------DEO2---------------------------
tic

lena=imread('../sekvence/lena_noise.tif ');
% figure;imshow(lena);

f=im2double(lena);
                %velicina bloka 
[M,N]=size(lena);
maxK=100;
nizVar=zeros(maxK,1);

for K=2:maxK
     
    havg=fspecial('average',[K,K]);       %funkcijom fspecial za parametar average 
                                          %dobijamo matricu velicine KxK sa
                                          %vrednostima 1/(K*K) , ovako dobijenu
                                          %matricu koristimo za izracunavanje
                                          %aritmeticke sredine svakog piksela
                                          %ponaosob i njegove okoline 

    gavg=imfilter(f,havg,'replicate');    %aritmeticke sredine piksela okoline K  

    gavg2=imfilter(f.^2,havg,'replicate');  %aritmeticke sredine kvadriranih piksela okoline K

    %po definiciji varijansa=(aritm sredina kvadriranih piksela)-(aritm sredina piksela iz okoline)^2


    varijansa=(gavg2-gavg.^2);      

    [brojPiksela,index]=imhist((varijansa));        %histogram varijanse
%   stem(index,brojPiksela);

    VAR=index(find(max(brojPiksela)==brojPiksela));     %Odredjivanje varijanse koja je najvise zastupljena 
                                                        %na slici.Za tako dobijenu
                                                        %varijansu smatramo da
                                                        %je uniformna na celoj
                                                        %slici
    nizVar(K-1)=VAR;
end;
vreme=toc;
%%
%--------------------DEO 3-----------------------

f=imread('../sekvence/etf_blur.tif');   %ucitavanje slike
f=im2double(f);             %konvertovanje u double format
[M,N]=size(f);              %dimenzije ulazne slike
F=fft2(f,M,N);              %prelazak u f domen


figure(1);imshow(f);           
title('Ulazna slika');

k=imread('../sekvence/kernel.tif');     %ucitavanje pokreta koji cemo koristiti za inverzno filtriranje    
k=im2double(k);
K=fft2(k,M,N);              %prelazak u frekv domen , isti broj tacaka kao
                            %ulazna slika

figure;
imshow(0.1*log(1+abs(fftshift(F))));
title('Spektar ulazne slike');

figure;
imshow(0.1*log(1+abs(fftshift(K))));
title('Spektar pokreta');

%inverzno filtriranje slike 
G=F./K;
G1=G; 

figure;
imshow(0.1*log(1+abs(fftshift(G1))));
title('Spektar slike posle inverznog filtriranja');


%Posle inverznog filtriranja dolazi do narusavanja srednje vrednosti slike
%zato radimo sledece skaliranje

G=G1*((max(abs(F(:)))/max(abs(G1(:)))));
%Nema potrebe da posmatramo skalirani spektar jer smo ga samo pomnozili
%nekim faktorom koji ne menja samu strukturu spektra


g=ifft2(G);         
figure(2);imshow(g);
title('Slika posle inverznog filtriranja i skaliranja');

%Slika je zasumljena pa je treba propustiti kroz neki filtar kako bi se izgubio sum.
%Za ovakvo fitriranje se koristi vinerov   filtar jer vrsi filtriranje u 
%zavisnosti od pokreta i zbog toga daje najbolju rekonstrukciju slike. 
%Poredjenja radi , uradicemo i low pass filtriranje cisto da se vidi razlika
   
Hlp=lpfilter('gaussian',M,N,110);   %formiranje LP filtra koji cemo iskoristiti za odsumljivanje
Glp=Hlp.*G;                         %filtriranje dobijene slike
glp=ifft2(Glp);                     

figure;
imshow(0.1*log(1+abs(fftshift(Glp))));
title('Spektar slike posle inverznog filtriranja i LP filtra');

Hv = (abs(K).^2)./(abs(K).^2 + 9);  %Formiranje vinerovog filtra koji se koristi za 
Gv = G.*Hv;                         %filtriranje slika posle inverznog filtriranja.
gv=ifft2(Gv);                       %Parametre samog filtra dobijamo eksperimentalno

figure;
imshow(0.1*log(1+abs(fftshift(Gv))));
title('Spektar slike posle inverznog filtriranja i vinerovog filtra');


glp=glp(1:530,1:800);       %odsecanje crnog okvira koji se javlja kao posledica
                            %konvolucije ulazne slike i pokreta slike
figure;imshow(glp);
title('Slika posle low pass filtriranja i odsecanja');


gv=gv(1:530,1:800);       %odsecanje crnog okvira koji se javlja kao posledica
                          %konvolucije ulazne slike i pokreta slike
figure;imshow(gv);
title('Slika posle vienovog filtriranja i odsecanja');

%%
%----------------------DEO 4--------------------------
%Vreme izvrsavanja ove tacke ume biti dosta veliko za slabije procesore
%pokretati po sektorima
lena=imread('../sekvence/lena_noise.tif ');
ref=im2double(imread('../sekvence/lena.tif'));

f=im2double(lena);
var=0.0078;
h=0.05;
vreme=zeros(9,1);
PSNR=zeros(9,1);

tic

J = dos_non_local_means (f, 3, 15, var, h);
figure;imshow(J);
title('K=3 S=15');
vreme(1)=toc;
PSNR(1)= psnr(J,ref);

tic

J1 = dos_non_local_means (f, 3, 33, var, h);
figure;imshow(J1);
title('K=3 S=33');
vreme(2)=toc;
PSNR(2)= psnr(J1,ref);


tic

J2 = dos_non_local_means (f, 3, 51, var, h);
figure;imshow(J2);
title('K=3 S=51');
vreme(3)=toc;
PSNR(3)= psnr(J2,ref);

tic

J3 = dos_non_local_means (f, 5, 15, var, h);
figure;imshow(J3);
title('K=5 S=15');
vreme(4)=toc;
PSNR(4)= psnr(J3,ref);


tic

J4 = dos_non_local_means (f, 5, 33, var, h);
figure;imshow(J4);
title('K=5 S=33');
vreme(5)=toc;
PSNR(5)= psnr(J4,ref);


tic

J5 = dos_non_local_means (f, 5, 51, var, h);
figure;imshow(J5);
title('K=5 S=51');
vreme(6)=toc;
PSNR(6)= psnr(J5,ref);

tic

J6 = dos_non_local_means (f, 9, 15, var, h);
figure;imshow(J6);
title('K=9 S=15');
vreme(7)=toc;
PSNR(7)= psnr(J6,ref);

tic

J7 = dos_non_local_means (f, 9, 33, var, h);
figure;imshow(J7);
title('K=9 S=33');
vreme(8)=toc;
PSNR(8)= psnr(J7,ref);


tic

J8 = dos_non_local_means (f, 9, 51, var, h);
figure;imshow(J8);
title('K=9 S=51');
vreme(9)=toc;
PSNR(9)= psnr(J8,ref);



