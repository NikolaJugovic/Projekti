clear all;
close all;
clc;




%%
%Zadatak1
I11=imread('clock2.png');
[Sati1 Minuti1]=extract_time(I11);

I12=imread('clock5.png');
[Sati2 Minuti2]=extract_time(I12);

I13=imread('clock7.jpg');
[Sati3 Minuti3]=extract_time(I13);


I14=imread('clock7.jpg');
[Sati4 Minuti4]=extract_time(I14);

I15=imread('clock10.jpg');
[Sati5 Minuti5]=extract_time(I15);
%%
%Malo duze se izvrsava ovaj deo zbog velike rezolucije slike
I16=imread('clock12.jpg');
[Sati6 Minuti6]=extract_time(I16);


%%
%Zadatak 2
I21=imread('dices2.jpg');
[Plave1 Crvene1]=extract_dice_score(I);

I22=imread('dices8.jpg');
[Plave2 Crvene2]=extract_dice_score(I);

I23=imread('dices11.jpg');
[Plave3 Crvene3]=extract_dice_score(I);


%%
%Zadatak 3
I31=(imread('lena.tif'));
J31=canny_edge_detection(I31,0.5,0.03,0.1);

I32=(imread('van.tif'));
J32=canny_edge_detection(I32,0.8,0.05,0.12);

I33=(imread('house.tif'));
J33=canny_edge_detection(I33,0.5,0.03,0.1);

I34=(imread('camerman.tif'));
J34=canny_edge_detection(I34,1.5,0.03,0.1);




