clear all;
close all;
clc;
%%
%--------------------1.1-----------------
%Poboljsavnje ajnstajnove gray slike
%Kod ovako blede slike razvlacenje kontrasta je dovljno odraditi 
%za njenu popravku. Postoji jos mnogo nacina za poboljsanje ovakve slike,
%jedan od njih je i skaliranje piksela koriscenjem logaritamske ili
%eksponencijalne funkcije , rezultat koji bi dobili bio bi u velikoj meri
%isti kao koriscenjem funkcije imadjust
a=imread('../sekvence/einstein_lc.tif');    
figure;
imshow(a);
histA=imhist(a);                                 %na osnovu histograma date slike  
                                                 %vidimo da je imadjust funkcija najbolja opcija za popravku slike   
a90=imadjust(a, [90 180]/255 ,[0 255]/255,1);    %najbolji odnos za popravljanje kontrasta
                                                 %smanjenje gama previse
  
                                                 %osvetljava sliku
figure;
bar(histA);
title('Histogram ulazne slike');
xlabel('Osvetljaji piksela');
ylabel('Broj piksela');


figure;
imshow(a90);



figure;
bar(imhist(a90));
title('Histogram poboljsane slike');
xlabel('Osvetljaji piksela');
ylabel('Broj piksela');

%%
%----------------1.2------------------
%poboljsanje giraff slike koja ima isti problem kao ajnstajn, slika ima
%suzen histogram pa je potrebno odraditi razvlacenje kontrasnta
g=imread('../sekvence/giraff.jpg');
figure;title('Ulazna slika');
imshow(g);
hista=imhist(g);
figure;bar(hista);title('Histogram ulazne slike');
xlabel('Osvetljaji piksela');
ylabel('Broj piksela');
                         

gk=imadjust(g,[95 160]/255, [0 255]/255);    %jednostavno razvlacenje kontrasta, granice podesene rucno

figure;
imshow(gk);
title('Izlazna slika');


histgk=imhist(gk);
figure;
bar(histgk);  
title('Histogram poboljsane slike');
xlabel('Osvetljaji piksela');
ylabel('Broj piksela');
                                             %izostravanje slike nema
                                             %smisla jer je slika ima
                                             %previse malu rezoluciju

%%

proba=imread('../sekvence/giraff.jpg');   

proba=im2double(proba);
pex=7 .*proba.^4;                           %razvlacenje kontrasta koriscenjem eksponencijalne 
ppex=im2uint8(pex);                         %funkcije , rezultat slican kao kod imadjust funkcije
                                            %sto je i ocekivano
figure;
imshow(ppex);
histexp=imhist(ppex);
figure;
bar(histexp);
title('Histogram poboljsane slike exp funkcijom');
xlabel('Osvetljaji piksela');
ylabel('Broj piksela');


%pokusaj izostravanja slike ,ali nije dovoljno dobrog kvaliteta slika


%%
%-----------------------1.3------------------
%popravka slike disney
%Kod slike disney treba popraviti osvetljenje i razvuci kontrast
%Problem koji se javlja kod ove slike je taj sto pri prevelikom razvlacenju
%kontrasta ili prevelikom osvetljavanju slike gubimo "informaciju" o nebu 
%Najbolji nacin za poboljsavanje ovakvih slika je da iz RGB formata
%predjemo u HSV ili YCrCb pa onda popravljamo gray komponentu te slike,na
%taj nacin uticemo samo na osvetljaj slike dok same boje ne menjamo
%Jos jedan nacin za popboljsavanje slke (sa malo komplikovanijim algoritmom)
%bi bio "odsecanje" neba i njegovo zasebno osvetljavanje , a zatim
%propustanje kroz lowpass filtar radi izjednacavanja ivica novonastale
%slike
disn=imread('../sekvence/disney.png');
disnHSV=rgb2hsv(disn);
disnV=disnHSV(:,:,3);
figure;imshow(disn);
disnVk=imadjust(disnV,[0 180]/255, [0 255]/255,0.65);
disnHSV(:,:,3)=disnVk;
disnRGB=hsv2rgb(disnHSV);
figure;imshow(disnRGB);

%%
%Sliku mozemo popraviti i preko YCbCr formata istim postupkom kao preko HSV
%formata,ali dobijamo znacajno losije rezultate
bY=rgb2ycbcr(disn);
Y=bY(:,:,1);

bY(:,:,1)=imadjust(Y,[0 200]/255,[0 1],0.8);

bYc=ycbcr2rgb(bY);
figure(7);
imshow(bYc);

%%
%----------------1.4-------------------
%popravka slike disney gray koriscenjem imadjust

disgr=rgb2gray(disn);
figure;
imshow(disgr);
disgr1=imadjust(disgr,[0 200]/255, [0 1], 0.65);
figure(2);
imshow(disgr1);
%%
%popravka slike disney gray koriscenjem logaritamske funkcije
disgr=im2double(disgr);
disgr2=log(1+6.*disgr)/1.8;
disgr2=im2uint8(disgr2);
figure(5);
imshow(disgr2);
figure(13);
bar(imhist(disgr2))

%%
%------------------1.5-----------------------
%Popravka slike bristolb

br=hdrread('../sekvence/bristolb.hdr');
figure(2);imshow(br);

R=br(:,:,1);
G=br(:,:,2);
B=br(:,:,3);
brG(:,:,1)=(R).^(1/2.8);                %gama korekcija ulazne slike
brG(:,:,2)=(G).^(1/2.8);
brG(:,:,3)=(B).^(1/2.8);

brG8=im2uint8(brG);
figure;imshow(brG8);title('bristolb posle gama korekcije');
brK=imadjust(brG8,[25 220]/255,[0 255]/255);     %razvlacenje kontrasta obradjene slike radi boljeg izgleda
figure(4);
imshow(brK);
title('bristolb posle gama korekcije i razvlacenja kontrasta');

%%
%---------------1.6------------
%obrada bristollb gray slike
%dovoljno je samo da uradimo gama korekciju 
brGr=rgb2gray(br);

% histbr=imhist(brGr);
% figure;
% bar(histbr);

brGrk=brGr.^(1/2.5);    %gama korekcija 

figure;imshow(brGrk);
% histbrk=imhist(brGrk1);
% figure;
% bar(histbrk);
%%
%--------------1.7-------------------
%popravljanje slike enigma
%

e=imread('../sekvence/enigma.png');
figure;imshow(e);


gmed=medfilt2(e,[10,10], 'symmetric');      %filtriranje medijan filtrom
figure;imshow(gmed);

gmax=ordfilt2(e,100,ones(10,10));   
gmin=ordfilt2(e,1,ones(10,10));

%izostravanje 
fest=e;
nind = (e == gmin) | (e == gmax);
fest(nind) = gmed(nind);
figure; imshow(fest);



%%
%--------------1.8----------------
%popravljanje kontrasta slika einstein_lc i bristolb koriscenjem funkcije 
%dos_chle
clear all;
a=imread('../sekvence/einstein_lc.tif');
a=im2double(a);
aK=dos_clhe(a,16,0.01);   
figure;
imshow(aK);
title('Ajnstajn popravljen pomocu dosclhe');

%%
b=hdrread('../sekvence/bristolb.hdr');
b=im2double(b);
bK=dos_clhe(b,20,1.2);  
figure;
imshow(bK);
title('Bristolb popravljen pomocu dosclhe');

%%
%testiranje funkcije za limit vrednosti 0,0.001,0.01,0.1 i 1
aK0=dos_clhe(a,8,0); 
aK1=dos_clhe(a,8,0.001);
aK2=dos_clhe(a,8,0.01);
aK3=dos_clhe(a,8,0.1);
aK4=dos_clhe(a,8,1);

figure;imshow(aK0);title('limit=0');
figure;imshow(aK1);title('limit=0.001');
figure;imshow(aK2);title('limit=0.01');
figure;imshow(aK3);title('limit=0.1');
figure;imshow(aK4);title('limit=1');

%%
%testiranje funkcije za bitDepth vrednosti 3,12,17,20,24
aK3=dos_clhe(a,3,0.01); 
aK12=dos_clhe(a,12,0.01); 
aK17=dos_clhe(a,17,0.01); 
aK20=dos_clhe(a,20,0.01);
aK24=dos_clhe(a,24,0.01);

figure;imshow(aK3);title('bitdepth=3');
figure;imshow(aK12);title('bitdepth=12');
figure;imshow(aK17);title('bitdepth=17');
figure;imshow(aK20);title('bitdepth=20');
figure;imshow(aK24);title('bitdepth=24');








