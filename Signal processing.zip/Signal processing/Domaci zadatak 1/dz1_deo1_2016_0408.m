clear all
clc
close all

%%
%Deo 1 pod 1


f1=1000;
f2=1240;
f3=1300;

%ucestanost diskretizacije
fs=10000;
Ts=1/fs;

fx=gcd(gcd(f1,f2),f3);

N=fs/fx;

 
 

 t = 0:Ts:(N-1)*Ts;
 

 x=5*cos(2*pi*f1*t)+1000*cos(2*pi*f2*t)+10*cos(2*pi*f3*t);
% ovakvo x nam je u stvari diskretan signal x[n] 
 

%%
 figure(1), 
 subplot(211), plot(t,x);
 title('Vremenski oblik signala');
 xlabel('t[s]');
 
 subplot(212), stem(t,x);
title('Vremenski oblik signala(stemovan)');
 xlabel('n[s]');
 

X=zeros(1,N);

n=0:N-1;
 Ws=exp(-1j*2*pi/N*n);
 for k = 1:N
     X(k) = sum(x.*(Ws.^(k-1)));
 end
 
 xl=length(X);
 
DF=fs/xl;   %frekvencijska rezolucija
 
 %dvostratni spektar
% f=0:DF:DF*(xl-1);
% 
% figure(2), stem(f,abs(X));

%jednostrani spektar
 Xp=X(1:N/2);
 fp=0:DF:DF*(xl/2-1);

% figure(3),stem(fp,abs(Xp));
% title('Spektar diskretizovang signala');
% xlabel('f[Hz]');

% realni i imaginarni deo
 figure(4);
 subplot(2,1,1);
 stem(0:DF:DF*(N/2-1),real(Xp));
 title('Realni deo');
 
 subplot(2,1,2);
 stem(0:DF:DF*(N/2-1),imag(Xp));
title('Imaginarni deo');
 xlabel('f[Hz]');
%%
%Deo 1 pod 2




%niz koji mi predstavlja prozorsku blekmanovu funkciju
w1=transpose(blackman(N));

%signal y je novi niz koji je dobijen mnozenjem diskretizovanog signala i
%prozorske funkcije

    y=x.*w1;

    
Y=zeros(1,N);
n=0:N-1;
 Ws=exp(-1j*2*pi/N*n);
 for k = 1:N
     Y(k) = sum(y.*(Ws.^(k-1)));
 end
 Yp=Y(1:N/2);
 
 % realni i imaginarni deo
figure(5);
subplot(2,1,1);
stem(0:DF:DF*(N/2-1),real(Yp));

title('realni deo');
xlabel('f[Hz]')


subplot(2,1,2);
stem(0:DF:DF*(N/2-1),imag(Yp));
title('imaginarni deo');
xlabel('f[Hz]')

%%
%Deo 1 pod 3 

%signal odabiramo  u 1.3N tacaka 
N1=1.3*N;
DF1=fs/N1;
t1=0:Ts:(N1*Ts-Ts);
x1=5*cos(2*pi*f1*t1)+1000*cos(2*pi*f2*t1)+10*cos(2*pi*f3*t1);
n1=0:N1-1;


 X1=zeros(1,N1);
 
 Ws1=exp(-1j*2*pi/N1*n1);
  for k = 1:N1
      X1(k) = sum(x1.*(Ws1.^(k-1)));
  end

 figure(34),stem(0:DF1:(floor(N1/2)-1)*DF1,20*log10(abs(X1(1:floor(N1/2)))));
 title('amplitudska karakteristika x u 1.3*N tacaka ')
xlabel('f[Hz]');
ylabel('|X1|[dB]');
    


    %pod a) pravougaona prozorska funkcija
prvgn=ones(1,N1);

y1=x1.*prvgn;


Y1=zeros(1,N1);

 Ws1=exp(-1j*2*pi/N1*n1);
 for k = 1:N1
     Y1(k) = sum(y1.*(Ws1.^(k-1)));
 end

Y1p=Y1(1:N1/2); 
 
figure(6);
subplot(2,2,1);
stem(0:DF1:DF1*(N1/2-1),20*log10(abs(Y1p)));
title('Pravougaona');

ylabel('|Y1|[dB]');
xlabel('f[Hz]');

    




    %pod b) trougaona prozorska funkcija
 w2=transpose(triang(N1));
    
 y2=x1.*w2;

    
Y2=zeros(1,N1);
n1=0:N1-1;

Ws1=exp(-1j*2*pi/N1*n1);
 for k = 1:N1
     Y2(k) = sum(y2.*(Ws1.^(k-1)));
 end

 Y2p=Y2(1:N1/2); 
 
 

subplot(2,2,2);
stem(0:DF1:DF1*(N1/2-1),20*log10(abs(Y2p)));
title('Trougaona');
ylabel('|Y2|[dB]');
xlabel('f[Hz]');




    %pod c) Hanova prozorska funkcija
    han=transpose(hann(N1));
   
    y3=x1.*han;

    Y3=zeros(1,N1);

 Ws1=exp(-1j*2*pi/N1*n1);
 for k = 1:N1
     Y3(k) = sum(y3.*(Ws1.^(k-1)));
 end

 Y3p=Y3(1:N1/2); 
 
 
subplot(2,2,3);

stem(0:DF1:DF1*(N1/2-1),20*log10(abs(Y3p)));
title('Hanova');
ylabel('|Y3|[dB]');
xlabel('f[Hz]');


    %pod d) Hemingova prozorska funkcija
   haming=transpose(hamming(N1));
   

    y4=x1.*haming;

Y4=zeros(1,N1);

 Ws1=exp(-1j*2*pi/N1*n1);
 for k = 1:N1
     Y4(k) = sum(y4.*(Ws1.^(k-1)));
 end

 Y4p=Y4(1:N1/2); 
 
 
subplot(2,2,4);

stem(0:DF1:DF1*(N1/2-1),20*log10(abs(Y4p)));
title('Hemingova');
xlabel('f[Hz]');
ylabel('|Y4|[dB]');
xlabel('f[Hz]');
    %pod e) Blekmenova prozorska funkcija
    bleki=transpose(blackman(N1));
   

    y5=x1.*bleki;

    Y5=zeros(1,N1);

 Ws1=exp(-1j*2*pi/N1*n1);
 for k = 1:N1
     Y5(k) = sum(y5.*(Ws1.^(k-1)));
 end

 Y5p=Y5(1:N1/2); 
 
 figure(7);
subplot(2,2,1);
stem(0:DF1:DF1*(N1/2-1),20*log10(abs(Y5p)));
title('Blekmenova');
ylabel('|Y5|[dB]');
xlabel('f[Hz]');



    %pod f),g) i h) kajzerova prozorska funkcija za beta=3,7,10
    kai1=transpose(kaiser(N1,3));
    kai2=transpose(kaiser(N1,7));
    kai3=transpose(kaiser(N1,10));
    
    
    y6=x1.*kai1;
    y7=x1.*kai2;
    y8=x1.*kai3;
    
    
    Y6=zeros(1,N1);
    Y7=zeros(1,N1);
    Y8=zeros(1,N1);

 Ws1=exp(-1j*2*pi/N1*n1);
 for k = 1:N1
     Y6(k) = sum(y6.*(Ws1.^(k-1)));
     Y7(k) = sum(y7.*(Ws1.^(k-1)));
     Y8(k) = sum(y8.*(Ws1.^(k-1)));
 
 
 end

 Y6p=Y6(1:N1/2); 
 Y7p=Y7(1:N1/2); 
 Y8p=Y8(1:N1/2); 
 
 
subplot(2,2,2);

stem(0:DF1:DF1*(N1/2-1),20*log10(abs(Y6p))); 
title('Kajzerova B=3');
ylabel('|Y6|[dB]');
xlabel('f[Hz]');
subplot(2,2,3);

stem(0:DF1:DF1*(N1/2-1),20*log10(abs(Y7p)));
title('Kajzerova B=7');
ylabel('|Y7|[dB]');
xlabel('f[Hz]');
subplot(2,2,4);

stem(0:DF1:DF1*(N1/2-1),20*log10(abs(Y8p)));
title('Kajzerova B=10');
 ylabel('|Y8|[dB]');
xlabel('f[Hz]');

%%
%Deo4 uzimanje svakog osmog odbirka
%Umesto frekvencijske rezolucije od 20Hz uzimamo frekv rezoluciju od 10Hz 
%da bi za svaki osmi clan bilo 125 clanova
f1=1000;
f2=1240;
f3=1300;
N8=1000;
fs=10000;
df8=fs/N8*8;
Ts8=1/fs;
t8=0:Ts8:(N8-1)*Ts8;
 x8=5*cos(2*pi*f1*t8)+1000*cos(2*pi*f2*t8)+10*cos(2*pi*f3*t8);   
 
 %uzimanje svakog osmog
    xd8=zeros(1,floor(length(x8)/8));
 for i=0:(length(x8)/8)-1
     xd8(i+1) = x8(8*i+1);
 
 end
 
 XD8=fft(xd8);
 XD8p=XD8(1:floor(length(XD8)/2));
 figure(56);
subplot (212);
 stem(df8:df8:fs/2,20*log10(abs(XD8p)));
 title('svaki osmi odbirak');
 xlabel('f[Hz]');
 ylabel('|Xd8|[dB]');
 
 subplot (211);
 stem(fp,20*log10(abs(Xp)));
 title('svaki odbirak');
 xlabel('f[Hz]');
 ylabel('|Xd|[dB]');
 
 
    
    
 
%%
%Deo 5 odredjivanje xchirp signala
fsc=8000;
Tsc=1/fsc;
nsc=0:Tsc:5-Tsc ;                  
Nsc=length(nsc);
scale=0:(1/(2*(Nsc-1))):1/2;

f1ch=f1*scale; f2ch=f2*scale; f3ch=f3*scale;

xchirp=5*cos(2*pi*nsc.*f1ch)+1000*cos(2*pi*nsc.*f2ch)+10*cos(2*pi*nsc.*f3ch);
plot(nsc,xchirp);


audio=audioplayer(xchirp,fsc);
% play(audio);



%%
%Deo 6 uzimanje svakog drugog, i uzimanje svakog petog odbirka,decimacija

xchirpd2=zeros(1,floor(length(xchirp)/2));
 for i=1:floor(length(xchirp)/2)
     xchirpd2(i) = xchirp(2*i);
 
 end



audio2=audioplayer(xchirpd2,fsc/2);
 %play(audio2);

xchirpd5=zeros(1,floor(length(xchirp)/5));
 for i=1:floor(length(xchirp)/5)
     xchirpd5(i) = xchirp(5*i);
 
 end

audio5=audioplayer(xchirpd5,fsc/5);
% play(audio5);



%%
%Deo 7 crtanje spektrograma
figure(15 );

subplot(311);
s=spectrogram(xchirp,8000);
spectrogram(xchirp,[], [] , fsc,fsc,'yaxis');

title('xchirp');
ylabel('');
xlabel('');

subplot(312);
s2=spectrogram(xchirpd2,8000);
spectrogram(xchirpd2,[], [] , fsc/2,fsc/2,'yaxis');
title('xchirpd2');
xlabel('');


subplot(313);
s5=spectrogram(xchirpd5,8000);
spectrogram(xchirpd5,[], [] , fsc/5,fsc/5,'yaxis');
title('xchirpd5');
ylabel('');
xlabel('t[s]');









