clear all
close all
clc



%%
%Deo 2 odredjivanje korelacije 
tic
R=block_correlation(received_sequence, pn_sequence,4095);
nasevreme=toc;
%%
%Deo3 poredjenje za funkcijom xcorr
tic
R1=xcorr(received_sequence,pn_sequence);
njihovovreme=toc;
figure(1),plot(1:length(R),R);

figure(2),plot(1:length(R1),R1);



%%
%Deo 4 odredjivanje maximuma funkcije, samim tim i pocetak korisnog signala

[M,I] = max(R);
maksimum=M;
poc=I;

%%
%Deo 5 dekodovanje signala 
y1=received_sequence(2381:end);
 
y=decode_sound(y1');

 %%
 audio=audioplayer(y,8000);

 audiowrite('govor.wav',y,8000);
% play(audio)
 
figure(23);

s=spectrogram(y);
spectrogram(y,'yaxis')
title('dekodovan signal');
xlabel('Samples');

figure(24);

s1=spectrogram(received_sequence);
spectrogram(received_sequence,'yaxis');
title('zasumljen signal');
xlabel('Samples');
%%
%Plotovanja potrebna za izvestaj

%pseudo slucajna sekvenca
figure(222);
stem(1:length(pn_sequence),pn_sequence);
title('Pseudo slucajna sekvenca');
xlabel('odbirci k[sec]');
axis([100 150 -2 2]);
%%
%zasumljena primljena sekvenca
figure(223);
plot(1:length(received_sequence),received_sequence);
title('Primljena zasumljena sekvenca');
xlabel('odbirci k');

%%
%kros korelacija dva sibala
figure(224);
plot(1:length(R),R);
title('kroskorelacija');
xlabel('odbirci k');




