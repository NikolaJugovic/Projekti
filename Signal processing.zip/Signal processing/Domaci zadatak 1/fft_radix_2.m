function X = fft_radix_2(x)
%% 
 N= length(x);                          
 persistent r
 if isempty(r)
     r=0;
 end
 
 r=r+1;                      %globalna promenljiva r, koja pamti broj ponoveljnih rekurzija
                                            
   
     
 
%provera za N i dopunjavanje nulama 
if (N == 1) 
    X=x;                    %slucaj kad je N=1, signal ostaje isti           
else
    xn=x;
    Nn = length(xn);
    if (r == 1)
        
    if (mod(log2(Nn),1)==0)
         
         
    else                            
    d=floor(log2(Nn))+1;    %2^p predstavlja duzinu novog niza ako
                            % N nije stepen dvojke

    dodatak=2^d-N ;              %broj nula koje treba dodati nizu da se dopuni do stepena dvojke
    
    xp=zeros(1,dodatak);
    xn=[x xp] ;                 %novo x sa dopunjenim nulama do stepena broja 2
    Nn=length(xn);
   end
    end
end


%%

Xn=zeros(1,Nn);



    h = 1;
    for it = 1:Nn
       
        if (mod(it,2) == 1)
            Xn(it) = xn(h) + xn(h + Nn/2);
        else
            Xn(it ) = (xn(h) - xn(h + Nn/2)); %deo samo za clanove koji se ne mnoze W faktorom i -1
            h = h + 1;
        end
    end
%%
    p = 0;              %  pomocna koja brine o stepenu W faktora
    W = exp(-2*pi*1j/Nn);
    for k = 1:Nn/2
        Xn(2*k) = Xn(2*k) * W^p;       % svaki paran mnozimo sa W faktorom
        if (mod(k,2^(r - 1)) == 0 )                      
            p = p + 2^(r - 1);                      
        end
    end
    
    
    %% Preuredjivanje 
    if (2^r ~= Nn)
        X=fft_radix_2(Xn);
    else
        Xt=Xn;
        X(bitrevorder(1:Nn))=Xt(1:Nn);       %svaki koeficijent dolazi na svoje mesto
        r=0;
    end
    
 end
    

    
    
    
    
     
     
 
 
 
 