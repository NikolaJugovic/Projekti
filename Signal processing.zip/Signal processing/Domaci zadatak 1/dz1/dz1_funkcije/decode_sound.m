function [y] = decode_sound(input_symbols)
%UNTITLED4 Summary of this function goes here

%Decode
% LDPC Decoder Configuration
load H_dec.mat
CW_length = 64800;
info_part_length = size(H_dec,2) - size(H_dec,1);
noise_sigma = 0.8;

ldpcPropertyValuePairs = { ...
    'MaximumIterationCount' , 50, ...
    'ParityCheckMatrix' , H_dec, ...
    'DecisionMethod' , 'Hard Decision', ...
    'IterationTerminationCondition' , 'Maximum iteration count', ...
    'OutputValue' , 'Information part'};
dec = comm.LDPCDecoder(ldpcPropertyValuePairs{:});
received_decoded_bits = [];

for i = 1:(length(input_symbols)/CW_length)
    CW = input_symbols((i-1)*CW_length+1:i*CW_length);
    decoded_bits = step(dec, 4*CW/(noise_sigma^2));
    received_decoded_bits = [received_decoded_bits; decoded_bits(1:info_part_length)];
end

x_bin = reshape(received_decoded_bits, [8, length(received_decoded_bits)/8])';
x_reconstructed = double(typecast(uint8(bin2dec(char(x_bin+'0'))),'int8'));

y = x_reconstructed/128;

end

