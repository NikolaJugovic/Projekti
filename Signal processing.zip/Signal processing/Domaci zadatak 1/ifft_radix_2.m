function x=ifft_radix_2(X)

%inverzna furijeova transformacija

if(mod(log2(length(X)),1) == 0)             %provera za ulazni niz, jel stepen dvojke
     x = 1/length(X)*1j * conj(fft_radix_2(1j*conj(X)));
else
    error('Ulazni vektor nije duzine koja je stepen broja 2')
end

end