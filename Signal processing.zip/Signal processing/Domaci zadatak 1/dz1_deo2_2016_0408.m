close all
clear all
clc



%Deo 3 zadatak 2 


%crtanje spektra izracunatog preko nase funkcije fft
f1=1000;
f2=1240;
f3=1300;

fs=10000;
Ts=1/fs;
fx=gcd(gcd(f1,f2),f3);  %trazenje nzda


N=fs/fx;
n=0:Ts:(N-1)*Ts;
x=5*cos(2*pi*f1*n)+1000*cos(2*pi*f2*n)+10*cos(2*pi*f3*n);
 
 X=fft_radix_2(x);
 rez=fs/length(X);  %rezolucija spektra
 
  Xp=X(1:length(X)/2);
 
 df=0:rez:(length(X)/2-1)*rez;
 
 
 figure(250),
 subplot(211);
 stem(df,(real(Xp)));
 title('realni deo fft radix 2');
 ylabel('');
 xlabel('f[Hz]');

subplot(212);
 stem(df,(imag(Xp)));
 title('imaginarni deo fft radix 2');
 ylabel('');
 xlabel('f[Hz]');
 
 
 X1=fft(x);
 X1p=X1(1:length(X1)/2);
 rez1=fs/length(X1);
 df1=0:rez1:(length(X1)/2-1)*rez1;
 
 
 figure(251);
 subplot(211);
 stem(df1,real(X1p));     %definitivno zavisi koliko tacaka uzmemo za fft, 
 ylabel('');
 xlabel('f[Hz]');
title('realni deo fft'); 
 
subplot(212);
 stem(df1,imag(X1p));     %definitivno zavisi koliko tacaka uzmemo za fft, 
 ylabel('');
 xlabel('f[Hz]');
title('imaginarni deo fft'); 
 
                                %ako uzmemo isti broj tacaka kao za fft_radix_2 algoritam
 ylabel('');
 xlabel('f[Hz]');                                 %spektri ce biti isti
                                  
 
 
 
 
  %%
  %Deo 4 ispitivanje funkcionalnosti ifft_radix_2, poredi se dobijeni
  %niz x , sa pocetnim nizom iz tacke 1 dela 1
  
  x1=ifft_radix_2(X); 
  
  n4=0:length(x1)-1;
  figure(3)
  subplot(211);
  plot(n4,real(x1));
  title('Niz posle ifft radix 2');
  xlabel('t[s]');
  
  
  n3=0:length(x)-1;
  subplot(212);
  plot(n3,x);
  title('Pocetni niz x');
  xlabel('t[s]');
  
  x2=ifft(X);
  n5=0:length(x2)-1;
  figure(5),plot(n5,real(x2));
  title('Niz posle ifft');
  
  
  
  
  
  %%
  %Deo 5 Dft i ampt spektar signala chopin.wav
                               
  [xc,fs] = audioread('chopin.wav');
    pocetak=1;
    kraj=1.25;
  trajanje=kraj-pocetak;
 xct=transpose(xc);
 
 Tst=30/length(xct);
 
 xc1=xct(pocetak/Tst:kraj/Tst);         %x koje koristimo
  
   
   tc1 = 0:Tst:(length(xc1)-1)*Tst;
  

sound(xc1);
figure(600);

plot(tc1,xc1);
title('Vremenski oblik signala chopin.wav od 1sec do 1,25sec (xc1)');
xlabel('t[s]');


%%
%merenje vremena izvrsavanja algoritma fft_radix_2

tic
XC1=fft_radix_2(xc1);



vreme1=toc;




%%

tic



%merenje vremena izvrsavanja po definiciji
 XC2=zeros(1,length(xc1));
 
 g=0:length(xc1)-1;
  Ws=exp(-1j*2*pi/length(xc1)*g);
  for k = 1:length(xc1)
      XC2(k) = sum(xc1.*(Ws.^(k-1)));
  end
  
  vreme2=toc;

  
 %%
 %Plotovanje spektara dobijenih preko DFT-a i preko fft_radix-a
 figure(5),plot(0:length(XC1)-1,20*log10(abs(XC1)));
 title('Sprektar signala xc1 dobijen funckijom fft radix 2');
 xlabel('f[Hz]');

 figure(6),plot(0:length(XC2)-1,20*log10(abs(XC2)));
 title('Sprektar signala xc1 dobijen DFT-om po definiciji');
 xlabel('f[Hz]');





