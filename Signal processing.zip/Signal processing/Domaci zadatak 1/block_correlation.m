 function  R = block_correlation(x, pn_seq, block_length)

 
 %duzine nizova
 
 Ls=length(x);
 M=length(pn_seq);
 L=block_length;
 
%novi niz dopunjen nulama tako da zadnji clan bude lepo sracunat

 xn=[x zeros(1,ceil(Ls/L)*L-Ls)];
 
 hn=[fliplr(pn_seq) zeros(1,L-1)];
 
 c=zeros(1,length(xn)+M-1);
 
 for i=1:ceil(Ls/L)
     xk=[xn((i-1)*L+1 : i*L ) zeros(1,M-1)];
     
     if (i==1)          %posebno posmatranje prvog clana
         
         
         C1=real(ifft_radix_2(fft_radix_2(xk) .* fft_radix_2(hn)));   %korelacija prvog clana i pseudo sekvence
         C1=C1(1:length(xk));
         c=C1(1:L);                                             %smestanje u konacan niz c koji se na kraju funkcije vrati
     else 
         Cx=real(ifft_radix_2(fft_radix_2(xk) .* fft_radix_2(hn)));        %korelacija ostalih clanova sa pn sekvencom
         Cx=Cx(1:length(xk));
         c = [c C1(L+1:L+M-1)+Cx(1:M-1) Cx(M:L)];                       %smestanje u konacan niz
        
         C1=Cx;                                                 % u sledecu iteracju C1 ulazi kao Cx i na taj nacin cuvamo informaciju o prethodnom clanu
     end
 end
 
c=[c C1(L+1:end)];                                                  %zadnji clan 

 R=c;
 end
 
 
 