function [b, a] = bandpass_filter(fs, fa, fp, Aa, Ap) 

if (fa(1)>fa(2) || fa(1)>fp(1) || fa(1) > fp(2) || fp(1)>fp(2) || fp(1)>fa(2)  || fp(2)>fa(2)) 
    error('Nepravilno uneti parametrii');
end

%ucestanosti koje su nam zadate
fa1=fa(1);
fa2=fa(2);
fp1=fp(1);
fp2=fp(2);


%pojacanje u propusnom i slabljenje u nepropusnom koje ce se menjati u
%petlji
Aapomocno=Aa;
Appomocno=Ap;
% Apglobalno=Ap;


%broj tacaka za freqz funkciju
Nfreqz = 10000;

wp1Predist=fp1*2*pi;
wp2Predist=fp2*2*pi;
wa1Predist=fa1*2*pi;
wa2Predist=fa2*2*pi;


%predistorzija za blinearnu transformaciju, odkomentarisati za bilinearnu
%sve ovo
% wa1Predist = 2*fs*tan(fa1*2*pi/fs/2);
% wa2Predist = 2*fs*tan(fa2*2*pi/fs/2);
% wp1Predist = 2*fs*tan(fp1*2*pi/fs/2);
% wp2Predist = 2*fs*tan(fp2*2*pi/fs/2);

%odredjivanje sirine propusnog opsega i centralne ucestanosti 

w0 = sqrt(wp1Predist*wp2Predist);

%pogorsavanje gabarita
if (wa2Predist > w0^2/wa1Predist)
   wa2Predist = w0^2/wa1Predist; 
end

B = wp2Predist-wp1Predist;
%normalizacija
wpN=1;
waN=1/B * (wa2Predist - wa1Predist);


while(1)
    k=sqrt(1-(wpN/waN)^2);
    D=(10^(0.1*Aapomocno)-1)/(10^(0.1*Appomocno)-1);
    q0=(1/2)*((1-sqrt(k))/(1+sqrt(k)));
    q=q0+2*q0^5+15*q0^9+15*q0^13;
    red=ceil(real(log10(16*D))/real(log10(1/q)));
    if red==0
        red=1;
    end
    
    [z,p,kp]=ellipap(red,Appomocno,Aapomocno);
    brojilac=kp*poly(z);
    imenilac=poly(p);

    %Transformacija normalizovanog prototipa u PO
    
    [numa,dena]=lp2bp(brojilac,imenilac,w0,B);       
    
    %diskretizacija
    [numd,dend]=impinvar(numa,dena,fs);
    
    
    %odkomentarisati za bilinearnu
%     [numd ,dend]=bilinear(numa,dena,fs);  
    
    
    
    %formiranje funkcije prenosa filtra
    [hd,Wd]=freqz(numd,dend,Nfreqz);
    Hd=abs(hd);
    fd=(Wd*fs)/(2*pi);

    %provera gabarita
    NOOK = 0;
    POOK = 0;
    df=(fs/2)/Nfreqz;

    ia1=ceil(fa1/df)+1;
    ia2=floor(fa2/df)+1;
    ip1=floor(fp1/df)+1;
    ip2=ceil(fp2/df)+1;

    Ha=[Hd(1:ia1)' Hd(ia2:end)'];   %Amplitudska Karakteristika Nepropusnog Opsega
    Hp=Hd(ip1:ip2);   %Amplitudska Karakteristika Propusnog Opsega
    
    
    if(max(20*log10(Ha))>-Aa)
        Aapomocno=Aapomocno+Aapomocno*0.1;
    else
        NOOK=1;
    end
    
    if(min(20*log10(Hp))<-Ap)
        Appomocno=Appomocno-Appomocno*0.1;
    else
        POOK=1;
    end   
    if((NOOK==1)&&(POOK==1))
        
        break
    end
    
end


b=numd;
a=dend;

 end