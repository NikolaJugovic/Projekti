clear all;
clc
close all;



%%

%------------------Zadatak 2 deo pod 3------------------------


%trebalo bi da su vrednosti ovako zadate i da je u postavci zadatka greska
Ap=0.05;
Aa=60;
fa=[7800 16200];
fp=[8000 16000];
fpBP(1)=fp(1);
fpBP(2)=fp(2);
faBP(1)=fa(1);
faBP(2)=fa(2);
fs=44100;
Nfreqz=10000;

%projektovanje propusnika opsega

[b,a]=bandpass_filter(fs,fa,fp,Aa,Ap);

 fvtool(b,a);
% title('Filtar propusnik opsega ucestanosti');


%propusnik visokih ucestanosti

fah=15800;
fph=16000;
[bh ,ah]=highpass_filter(fs,fah,fph,Aa,Ap);

 fvtool(bh,ah);
% title('Filtar propusnik visokih ucestanosti');



% Ha=[Hd(1:ia1)' Hd(ia2:end)'];   %Amplitudska Karakteristika Nepropusnog Opsega
%     Hp=Hd(ip1:ip2);  


[hd,Wd]=freqz(b,a,Nfreqz);
    Hd=abs(hd);
    fd=(Wd*fs)/(2*pi);

[hdh,Wdh]=freqz(bh,ah,Nfreqz);
    Hdh=abs(hdh);
    fdh=(Wdh*fs)/(2*pi);





%amplitudska karakteristika digitalnog filtra 
%za filtar propusnik opsega ucestanosti

figure(1);

plot(fd,20*log10(Hd), 'LineWidth', 2);

title('Amplitudska karakteristika filtra propusnika opsega ucestanosti ');
xlabel('Ucestanost (Hz)');
ylabel('|H(z)|dB');


%crtanje gabarita
hold on
x_1 = [0 faBP(1)]; y_1 = [-Aa -Aa];       %nepropusni deo
x_2 = [faBP(1) faBP(1)]; y_2 = [-Aa -Ap];

x_3 = [faBP(2) faBP(2)]; y_3 = [-Aa -Ap];       %nepropusni deo
x_4 = [faBP(2) fs/2]; y_4 = [-Aa -Aa];

x_5 = [fpBP(1) fpBP(2)]; y_5 = [-Ap -Ap];       %propusni deo
x_6 = [fpBP(1) fpBP(1)]; y_6 = [-Aa -Ap];
x_7 = [fpBP(2) fpBP(2)]; y_7 = [-Aa -Ap];

plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'LineWidth',0.5);




%amplitudska karakteristika digitalnog filtra
%za filtar propusnik visokih ucestanosti
figure(2);

plot(fdh,20*log10(Hdh), 'LineWidth', 2);


title('Amplitudska karakteristika filtra propusnika visokih ucestanosti ');
xlabel('Ucestanost (Hz)');
ylabel('|H(z)|dB');


%gabariti za dati filtar
hold on

x_1h = [0 fah]; y_1h = [-Aa -Aa];        %ogranicenje za nepropusni deo
x_2h = [fah fah]; y_2h = [-Aa -Ap];

x_3h= [fph fph]; y_3h= [-Aa -Ap ];
x_4h= [fph fs/2];   y_4h= [-Ap -Ap ];   %ogranicenja za propusni deo

plot (x_1h,y_1h,'r',x_2h,y_2h,'r',x_3h,y_3h,'r',x_4h,y_4h,'r','LineWidth',0.5);


%%
%-----------------------Zadatak 2 Deo pod 5----------------------------

%impulsni odziv ekvalizatora

%kreiranje diraka

t=0:0.01:100;

x=zeros(1,length(t));
x(1)=1;


%impulsni CUSTOM ekv
yImpC=IIR_equalizer(x,44100,'CUSTOM');
figure(10);
subplot(411);
plot(t,yImpC');
title('impulsni odziv ekvilajzera za CUSTOM,ROCK,POP i DANCE tip');
% xlabel('time[s]');



%impulsni ROK ekv
yImpR=IIR_equalizer(x,44100,'ROCK');
subplot(412);
plot(t,yImpR');
% title('impulsni odziv ekvilajzera za ROCK tip');
% xlabel('time[s]');


%impulsni POP ekv
yImpP=IIR_equalizer(x,44100,'POP');
subplot(413);
plot(t,yImpP');
% %title('impulsni odziv ekvilajzera za POP tip');
% xlabel('time[s]');



%impulsni DANCE ekv
yImpD=IIR_equalizer(x,44100,'DANCE');
subplot(414);
plot(t,yImpD');
% title('impulsni odziv ekvilajzera za DANCE tip');
xlabel('time[s]');

%%

%--------------------------Zadatak 2 Deo pod 6----------------------


%frekvencijska karakteristika impulsnog odziva ekvalizatora i odredjivanje
%dft-a


%dft impulsnih  odziva razlicitih tipova muzike

yImpCf=fft(yImpC,20000);
yImpRf=fft(yImpR,20000);
yImpPf=fft(yImpP,20000);
yImpDf=fft(yImpD,20000);



%crtanje frekvencijskih karakteristika impulsnih odziva

fs=44100;
df=fs/length(yImpCf);



%za CUSTOM(u skladu sa menjanjem  parametara u funkciji IIR_equalization 
%menjaju se i grafici amplitude i faze , tako da je funkcija IIR dobra)


figure(23)
subplot(211);
semilogx(15*df:df:fs/2,20*log10(abs(yImpCf(15:floor(length(yImpCf))/2))));
title('Amplitudska karakteristika impulsnog odziva za CUSTOM');
xlabel('f[Hz]');

subplot(212);
semilogx(df:df:fs/2,angle(yImpCf(1:floor(length(yImpCf)/2))));
title('Fazna karakteristika impulsnog odziva za CUSTOM');
xlabel('f[Hz]');




%za DANCE

figure(24)
subplot(211);
semilogx(14*df:df:fs/2,20*log10(abs(yImpDf(14:floor(length(yImpDf))/2))));
title('Amplitudska karakteristika impulsnog odziva za DANCE');
xlabel('f[Hz]');

subplot(212);
semilogx(df:df:fs/2,angle(yImpDf(1:floor(length(yImpDf)/2))));
title('Fazna karakteristika impulsnog odziva za DANCE');
xlabel('f[Hz]');




%za POP
figure(25)
subplot(211);
semilogx(14*df:df:fs/2,20*log10(abs(yImpPf(14:floor(length(yImpPf))/2))));
title('Amplitudska karakteristika impulsnog odziva za POP');

subplot(212);
semilogx(df:df:fs/2,angle(yImpPf(1:floor(length(yImpPf)/2))));
title('Fazna karakteristika impulsnog odziva za POP');
xlabel('f[Hz]');


%za ROCK
figure(26)
subplot(211);
semilogx(14*df:df:fs/2,20*log10(abs(yImpRf(14:floor(length(yImpRf))/2))));
title('Amplitudska karakteristika impulsnog odziva za ROCK');

subplot(212);
semilogx(df:df:fs/2,angle(yImpRf(1:floor(length(yImpRf)/2))));
title('Fazna karakteristika impulsnog odziva za ROCK');
xlabel('f[Hz]');

%%
%----------------------Zadatak 2 Deo pod 7 -------------------------

%ucitavanje sopena i snimanje u equliazed sound 


[sopen, fss]=audioread('chopin.wav');

sopenEq=IIR_equalizer(sopen,44100,'ROCK'); %nece se primetiti nikakva promena 

audiowrite('equalized_sound.wav',sopenEq,44100);



%%
%---------------------Zadatak2 Deo pod 8-----------------------------

%crtanje koriscenih filtara iz tacke 4

%prvo crtanje za highpass
fs=44100;
Aa=60;
Ap=0.5;
fa=15800;
fp=16000;
[bVF,aVF]=highpass_filter(fs,fa,fp,Aa,Ap);

[hd,Wd]=freqz(bVF,aVF,20000);
    Hd=abs(hd);
    fd=(Wd*fs)/(2*pi);

figure(41);
plot(fd,20*log10(Hd), 'LineWidth', 0.5);
title('Amplitudska karakteristika filtra propusnika visokih ucestanosti');
xlabel('Ucestanost (Hz)');
ylabel('|H(z)|');
hold on;




x_1 = [0 fa];       y_1 = [-Aa -Aa];
x_2 = [fa fa];      y_2 = [-Aa -Ap];

x_3 = [fp fs/2];	y_3 = [-Ap -Ap];
x_4 = [fp fp];      y_4 = [-Aa -Ap];

 plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r','LineWidth',0.5);

hold off
 

 %crtanje bandpass filtra---------------------------------
 faBP=[7800 16200];
 fpBP=[8000 16000];
  
 [bBP,aBP]=bandpass_filter(fs,faBP,fpBP,Aa,Ap);
 
 [hdBP,WdBP]=freqz(bBP,aBP,20000);
    HdBP=abs(hdBP);
    fdBP=(WdBP*fs)/(2*pi);

 
 %amplitudska karakteristika band passa


figure(42);
plot(fdBP,20*log10(HdBP), 'LineWidth', 0.5);
title('Amplitudska karakteristika filtra propusnika opsega ucestanosti');
xlabel('Ucestanost (Hz)');
ylabel('|H(z)|');

%crtanje gabarita
hold on
x_1 = [0 faBP(1)]; y_1 = [-Aa -Aa];
x_2 = [faBP(1) faBP(1)]; y_2 = [-Aa -Ap];

x_3 = [faBP(2) fs/2]; y_3 = [-Aa -Aa];
x_4 = [faBP(2) faBP(2)]; y_4 = [-Aa -Ap];

x_5 = [fpBP(1) fpBP(2)]; y_5 = [-Ap -Ap];
x_6 = [fpBP(1) fpBP(1)]; y_6 = [-Aa -Ap];
x_7 = [fpBP(2) fpBP(2)]; y_7 = [-Aa -Ap];

plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
hold off





%crtanje lowpass filtra

fs=44100;
AaLP=60;
ApLP=0.5;
faLP=16100;
fpLP=16000;
[bLP,aLP]=lowpass_filter(fs,faLP,fpLP,AaLP,ApLP);

[hdLP,WdLP]=freqz(bLP,aLP,20000);
    HdLP=abs(hdLP);
    fdLP=(WdLP*fs)/(2*pi);

figure(43);
plot(fdLP,20*log10(HdLP), 'LineWidth', 0.5);
title('Amplitudska karakteristika filtra propusnika niskih ucestanosti');
xlabel('Ucestanost (Hz)');
ylabel('|H(z)|');
hold on;




x_1 = [0 fpLP];       y_1 = [-ApLP -ApLP];
x_2 = [fpLP fpLP];      y_2 = [-AaLP -ApLP];

x_3 = [faLP fs/2];	y_3 = [-AaLP -AaLP];
x_4 = [faLP faLP];      y_4 = [-AaLP -ApLP];

 plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r','LineWidth',0.5);

hold off