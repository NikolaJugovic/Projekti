clear all
clc
close all
%%
%*****************Prvi zadatak Deo 1**********************

%ucitavanje note A
fs=44100;                   %frekvencija ucitavanja za pesme 

[A, fsA]=audioread('..\dz2_signali\allplusA.wav');   %ucitavanje note A         
figure(1)
trajanje=length(A)/fsA;                %trajanje ucitanog zvucnog signala u sekundama
plot(0:1/fsA:trajanje-1/fsA,A');              %crtanje u vremenskom domenu
xlabel('t[s]');                   
title('Nota A u vremenskom domenu');
ylabel('Amplituda ucitanog signala');
% sound(A,fsA);



%%

%ucitavanje dela pesme sa unetom notom A

[plusA, fsplusA]=audioread('..\dz2_signali\noteA.wav');
figure(2)
trajanje=length(plusA)/fsplusA;
plot(0:1/fsplusA:trajanje-1/fsplusA,plusA');

xlabel('t[s]');
title('Pesma+nota A');
ylabel('Amplituda ucitanog signala');
% sound(plusA,fsplusA);








%%
%****************Prvi zadatak Deo 3*********************

%crtanje spektrograma



nfft = 4096; 
window_width = nfft;
overlap_num = 3/4*window_width;

ws = hamming(window_width);

%racunanje spektrograma za signal "noteA"
[B1,frequencies1,times1] = spectrogram(A, ws, overlap_num, nfft, fsA);
B1_dB = 20*log10(abs(B1)); %u dB

%racunanje spektrograma za signal "allplusA"
[B2,frequencies2,times2] = spectrogram(plusA, ws, overlap_num, nfft, fsplusA);
B2_dB = 20*log10(abs(B2)); %u dB

% prikaz spektrograma
figure;
subplot(121)
imagesc(times1, frequencies1(1:end/4), B1_dB(1:end/4,:));
axis('xy');
xlabel('vreme [s]');
ylabel('ucestanost [Hz]');
title('notaA ');


subplot(122)
imagesc(times2, frequencies2(1:end/4), B2_dB(1:end/4,:));
axis('xy');
xlabel('vreme [s]');
ylabel('ucestanost [Hz]');
title('pesma + nota A');








%%
%************************Prvi zadatak Deo 4************************


%filtriranje signala , na osnovu spektrograma odrjedjujemo koje ucestanosti
%treba da budu filtrirane 
%pomaze nam to sto u spektrogramu postoji periodicnost na 220Hz pa moze 
%filtriranje signala da se izvrsi pomocu jedne for petlje


period=220;
fGornjeNP=6840;       %ucestanost do koje se filtriranje vrsi            
fDonjeNP=200;         %ucestanost od koje pocinje filtriranje
inkrement=40;      %opseg koji se filtrira
fGornjeP=6800+inkrement;
fDonjeP=160;
prelaznaZona=fDonjeNP-fDonjeP;
Aa=30;   
Ap=3;

[b, a]=bandstop_filter_Cheb2(44100,[fDonjeNP,fDonjeNP+inkrement],[fDonjeP,170+inkrement+2*prelaznaZona],Aa,Ap);
    
 Y=filter(b,a,plusA);
 N=1;
 
 %svakom iteracijom for petlje se formira novi filtar koji je u skladu sa
 %nasim zahtevima za filtriranje
 
for i=1:floor((fGornjeNP-inkrement)/period)   
    [b, a]=bandstop_filter_Cheb2(44100,[fDonjeNP+i*period,fDonjeNP+i*period+inkrement],[fDonjeP+i*period,170+inkrement+2*prelaznaZona+i*period],30,3);
   
    Y=filter(b,a,Y);
%     display(fDonjeNP+i*period)
%     display(fDonjeNP+i*period+inkrement)
    N=N+1;   %broj formiranih filtara
end



sound(Y,44100);
audiowrite('all.wav',Y,44100);




%za filtrirani signal crtamo spektrogram , cisto da vidimo jesu li
%isfiltrirane ucestanosti koje smo hteli da odbacimo

[B2f,frequencies2f,times2f] = spectrogram(Y, ws, overlap_num, nfft,fsplusA);
B2f_dB = 20*log10(abs(B2f)); %u dB


figure(3);
subplot(122);
imagesc(times2f, frequencies2f(1:end/4), B2f_dB(1:end/4,:));
axis('xy');
xlabel('vreme [s]');
ylabel('ucestanost [Hz]');
title('pesma bez note A');



%za nefiltrirani signal
[B2,frequencies2,times2] = spectrogram(plusA, ws, overlap_num, nfft, fsplusA);
B2_dB = 20*log10(abs(B2)); %u dB



subplot(121)

imagesc(times2, frequencies2(1:end/4), B2_dB(1:end/4,:));
axis('xy');
xlabel('vreme [s]');
ylabel('ucestanost [Hz]');
title('pesma + nota A');











%%
%************************Prvi zadatak Deo 5************************
%plotovanje koriscenih filtara u prethodnoj tacki
%preko subplota filtri ispadaju dosta nepregledni ,ostavljen je subplot kao
%zakomentarisan i ukoliko je potrebno takvo plotovanje dovoljno je samo da
%se odkomentarisu sve zakomentarisne komande subplota


fa=[0 0];
fp=[0 0];
for i=0:floor((fGornjeNP-inkrement)/period)              %ceil ovde ide zbog onog pocetnog filtriranja pre for petlje iz tacke 4
    [b, a]=bandstop_filter_Cheb2(44100,[fDonjeNP+i*period,fDonjeNP+i*period+inkrement],[fDonjeP+i*period,fDonjeP+inkrement+2*prelaznaZona+i*period],30,3);
    
    fa(1)=fDonjeNP+i*period;
    fa(2)=fDonjeNP+i*period+inkrement;
    fp(1)=fDonjeP+i*period;
    fp(2)=170+inkrement+2*prelaznaZona+i*period;
            [hd,Wd]=freqz(b,a,25000);
            Hd=abs(hd);
            fd=Wd*fs/(2*pi);
            
f = Wd/(2*pi)*fs;


            if (i<=3)
                    figure(5);
                    
%                     subplot(4,1,mod(i,4)+1);
                    plot(f,20*log10(Hd), 'LineWidth', 2);
                    grid on;
                   if i==0 
                       title('Filtri (1,2,3 i 4)/31 korisceni za filtriranje signala');
                   end
                    
                   if i==3
                       xlabel('Ucestanost (Hz)');
                   end 
                       ylabel('|H(z)|');
                    
                    hold on

                    %crtanje gabarita
                    hold on
                    x_1 = [0 fp(1)]; y_1 = [-Ap -Ap];
                    x_2 = [fp(1) fp(1)]; y_2 = [-Ap -Aa];

                    x_3 = [fp(2) fs/2]; y_3 = [-Ap -Ap];
                    x_4 = [fp(2) fp(2)]; y_4 = [-Ap -Aa];

                    x_5 = [fa(1) fa(2)]; y_5 = [-Aa -Aa];
                    x_6 = [fa(1) fa(1)]; y_6 = [0 -Aa];
                    x_7 = [fa(2) fa(2)]; y_7 = [0 -Aa];

                    plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
                    hold on
            
            
                    
            
            end
            
            

          
             if (i >= 4) && (i<=7)
                            figure(6);
                        
%                             subplot(4,1,mod(i,4)+1);
                            plot(f,20*log10(Hd), 'LineWidth', 2);
                            if i==4 
                                title('Filtri (5,6,7 i 8)/31 korisceni za filtriranje signala');
                            end
                            
                            
                            grid on;
                            if i==7

                            xlabel('Ucestanost (Hz)');
                            end

                            ylabel('|H(z)|');
                            hold on

                            %crtanje gabarita
                            hold on
                            x_1 = [0 fp(1)]; y_1 = [-Ap -Ap];
                            x_2 = [fp(1) fp(1)]; y_2 = [-Ap -Aa];

                            x_3 = [fp(2) fs/2]; y_3 = [-Ap -Ap];
                            x_4 = [fp(2) fp(2)]; y_4 = [-Ap -Aa];

                            x_5 = [fa(1) fa(2)]; y_5 = [-Aa -Aa];
                            x_6 = [fa(1) fa(1)]; y_6 = [0 -Aa];
                            x_7 = [fa(2) fa(2)]; y_7 = [0 -Aa];

                            plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
                            hold on
             end
               
             if (i >= 8) && (i<=11)
                            figure(7);
                        
%                             subplot(4,1,mod(i,4)+1);
                        
                            plot(f,20*log10(Hd), 'LineWidth', 2);
                            if i==8
                             title('Filtri (9,10,11 i 12)/31 korisceni za filtriranje signala');
                            end
                            grid on;
                            if i==11

                            xlabel('Ucestanost (Hz)');
                            end

                            ylabel('|H(z)|');
                            hold on

                            %crtanje gabarita
                            hold on
                            x_1 = [0 fp(1)]; y_1 = [-Ap -Ap];
                            x_2 = [fp(1) fp(1)]; y_2 = [-Ap -Aa];

                            x_3 = [fp(2) fs/2]; y_3 = [-Ap -Ap];
                            x_4 = [fp(2) fp(2)]; y_4 = [-Ap -Aa];

                            x_5 = [fa(1) fa(2)]; y_5 = [-Aa -Aa];
                            x_6 = [fa(1) fa(1)]; y_6 = [0 -Aa];
                            x_7 = [fa(2) fa(2)]; y_7 = [0 -Aa];

                            plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
                            hold on
             end
             
             if (i >= 12) && (i<=15)
                                figure(8);
                             
%                                 subplot(4,1,mod(i,4)+1);
                                plot(f,20*log10(Hd), 'LineWidth', 2);
                                 
                                if i==12
                                     title('Filtri (13,14,15 i 16)/31 korisceni za filtriranje signala');
                                end

                                
                                grid on;
                                if i==15

                                xlabel('Ucestanost (Hz)');
                                end

                                ylabel('|H(z)|');
                                hold on

                                %crtanje gabarita
                                hold on
                                x_1 = [0 fp(1)]; y_1 = [-Ap -Ap];
                                x_2 = [fp(1) fp(1)]; y_2 = [-Ap -Aa];

                                x_3 = [fp(2) fs/2]; y_3 = [-Ap -Ap];
                                x_4 = [fp(2) fp(2)]; y_4 = [-Ap -Aa];

                                x_5 = [fa(1) fa(2)]; y_5 = [-Aa -Aa];
                                x_6 = [fa(1) fa(1)]; y_6 = [0 -Aa];
                                x_7 = [fa(2) fa(2)]; y_7 = [0 -Aa];

                                plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
                                hold on
                  end

                         if (i >= 16) && (i<=19)
                                figure(9);
                           
%                                 subplot(4,1,mod(i,4)+1);
                                plot(f,20*log10(Hd), 'LineWidth', 2);
                                grid on;
                                
                                if i==16
                                 title('Filtri (17,18,19 i 20)/31 korisceni za filtriranje signala');
                                end
                                
                                if i==19
                                
                                xlabel('Ucestanost (Hz)');
                                end

                                ylabel('|H(z)|');
                                hold on

                                %crtanje gabarita
                                hold on
                                x_1 = [0 fp(1)]; y_1 = [-Ap -Ap];
                                x_2 = [fp(1) fp(1)]; y_2 = [-Ap -Aa];

                                x_3 = [fp(2) fs/2]; y_3 = [-Ap -Ap];
                                x_4 = [fp(2) fp(2)]; y_4 = [-Ap -Aa];

                                x_5 = [fa(1) fa(2)]; y_5 = [-Aa -Aa];
                                x_6 = [fa(1) fa(1)]; y_6 = [0 -Aa];
                                x_7 = [fa(2) fa(2)]; y_7 = [0 -Aa];

                                plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
                                hold on
                         end
             
             if (i >= 20) && (i<=23)
                                figure(10);
                            
%                                 subplot(4,1,mod(i,4)+1);
                                plot(f,20*log10(Hd), 'LineWidth', 2);
                                
                                 if i==20
                                 title('Filtri (21,22,23 i 24)/31 korisceni za filtriranje signala');
                                 end
                                
                                grid on;
                                if i==23

                                xlabel('Ucestanost (Hz)');
                                end

                                ylabel('|H(z)|');
                                hold on

                                %crtanje gabarita
                                hold on
                                x_1 = [0 fp(1)]; y_1 = [-Ap -Ap];
                                x_2 = [fp(1) fp(1)]; y_2 = [-Ap -Aa];

                                x_3 = [fp(2) fs/2]; y_3 = [-Ap -Ap];
                                x_4 = [fp(2) fp(2)]; y_4 = [-Ap -Aa];

                                x_5 = [fa(1) fa(2)]; y_5 = [-Aa -Aa];
                                x_6 = [fa(1) fa(1)]; y_6 = [0 -Aa];
                                x_7 = [fa(2) fa(2)]; y_7 = [0 -Aa];

                                plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
                                hold on
             end
             
             
             
             
             if (i >= 24) && (i<=27)
                                figure(11);
                            
%                                 subplot(4,1,mod(i,4)+1);
                                plot(f,20*log10(Hd), 'LineWidth', 2);
                                 
                                
                                 if i==24
                                 title('Filtri (25,26,27 i 28)/31 korisceni za filtriranje signala');
                                 end
                                
                                
                                grid on;
                                if i==27

                                xlabel('Ucestanost (Hz)');
                                end

                                ylabel('|H(z)|');
                                hold on

                                %crtanje gabarita
                                hold on
                                x_1 = [0 fp(1)]; y_1 = [-Ap -Ap];
                                x_2 = [fp(1) fp(1)]; y_2 = [-Ap -Aa];

                                x_3 = [fp(2) fs/2]; y_3 = [-Ap -Ap];
                                x_4 = [fp(2) fp(2)]; y_4 = [-Ap -Aa];

                                x_5 = [fa(1) fa(2)]; y_5 = [-Aa -Aa];
                                x_6 = [fa(1) fa(1)]; y_6 = [0 -Aa];
                                x_7 = [fa(2) fa(2)]; y_7 = [0 -Aa];

                                plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
                                hold on
             end
             
             
             
                    if (i >= 28) && (i<=30)
                            figure(12);
                        
%                             subplot(4,1,mod(i,4)+1);
                            plot(f,20*log10(Hd), 'LineWidth', 2);
                            
                             if i==28
                             title('Filtri (29,30 i 31)/31 korisceni za filtriranje signala');
                             end
                            
                            grid on;
                            if i==31

                            xlabel('Ucestanost (Hz)');
                            end

                            ylabel('|H(z)|');
                            hold on

                            %crtanje gabarita
                            hold on
                            x_1 = [0 fp(1)]; y_1 = [-Ap -Ap];
                            x_2 = [fp(1) fp(1)]; y_2 = [-Ap -Aa];

                            x_3 = [fp(2) fs/2]; y_3 = [-Ap -Ap];
                            x_4 = [fp(2) fp(2)]; y_4 = [-Ap -Aa];

                            x_5 = [fa(1) fa(2)]; y_5 = [-Aa -Aa];
                            x_6 = [fa(1) fa(1)]; y_6 = [0 -Aa];
                            x_7 = [fa(2) fa(2)]; y_7 = [0 -Aa];

                            plot(x_1,y_1,'r',x_2,y_2,'r',x_3,y_3,'r',x_4,y_4,'r',x_5,y_5,'r',x_6,y_6,'r',x_7,y_7,'r','LineWidth',1.5);
                            hold on
                    end
             
end
            
            
            
            
            
            
            
            
            
            
            
            
    










