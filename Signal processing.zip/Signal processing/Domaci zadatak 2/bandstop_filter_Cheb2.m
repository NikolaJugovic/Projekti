function [ b , a ] = bandstop_filter_Cheb2( fs, fa, fp, Aa, Ap )

%za slucaj da je funkcija lose pozvana
if ((fp(1) > fa(1)) || (fa(1) >fa(2)) || (fa(2) >fp(2)) || (fp(1) >fp(2)) || (Aa <= Ap))
    error('Pogresno pozvano');
end











N=0;            %odredjivace bro iteracija

Nfreqs=10000;  %broj tacaka u koliko 



%prelazak iz frekvencije na kruznu ucestanost

Wa1=2*pi*fa(1);
Wa2=2*pi*fa(2);
Wp1=2*pi*fp(1);
Wp2=2*pi*fp(2);


%predistorzija zbog bilinearne transformacije
Wa1Predist = 2*fs*tan(Wa1/fs/2);
Wa2Predist = 2*fs*tan(Wa2/fs/2);
Wp1Predist = 2*fs*tan(Wp1/fs/2);
Wp2Predist = 2*fs*tan(Wp2/fs/2);


%inicijalizovanje novih pojacanja i oslabljenja kako se pocetni ne bi
%menjali
Aapomocno=Aa;
Appomocno=Ap;
Aaglobalno=Aa; % ovo slabljenje cemo smanjivati za zadati parametar, ukoliko
               % je ulazno slabljenje bas veliko 

parametar=1; % ukoliko je zadato previse veliko slabljenje za previse strm
%prelazni opseg filtar nece moci da se formira i funkcija upada u
%beskonacnu petlju.Iz tog razloga ulazno slabljenje ce se smanjivati za 
%dati parametar dok ne postane prihvatljivo



%pronalazenje sirine nepropusnog opsega(koren iz kolicnika jer je log
%razmera)

W0=sqrt(Wa1Predist*Wa2Predist);
B=Wa2Predist-Wa1Predist;


%izjednacavanje strana 
if (Wp1Predist < W0 ^ 2 / Wp2Predist)
    Wp1Predist = W0 ^ 2 / Wp2Predist;
elseif (Wp2Predist > W0 ^ 2 / Wp1Predist)
    Wp2Predist = W0 ^ 2 / Wp1Predist;
end

Wan=1;
Wpn = (B * Wp1Predist) / (W0^2 - Wp1Predist^2);

while  (1)
            N=N+1;
            
            %parametri za red filtra
            k=Wpn/Wan;
            D = (10^(0.1*Aapomocno)-1)/(10^(0.1*Appomocno)-1);
            
            red=ceil(real(acosh(sqrt(D)))/real(acosh(1/k)));
            if red==0       %puca funkcija ako je red nula , moze da se desi da bude nula i ako se koristi ceil
                red=1;
            end;
            
             
          
            
           [z,p,ka]=cheb2ap(red,Aapomocno); %formiranje NF filtra ,z i p su koeficijenti u brojiocu i imeniocu
            
           
            brojilac=ka*poly(z);                %formiranje polinoma od koeficijenata
            imenilac=poly(p);

            
            
            %prelazak iz NF u NEPROPUSNIK OPSEGA
            [num,den] = lp2bs(brojilac,imenilac,W0,B);      
            
            %diskretizacija preko bilinearne(sredjena je predistorzija)
            [numd,dend]=bilinear(num,den,fs);
            
            %formiranje funkcije prenosa u Nfreqs tacaka 
            
            [hd,Wd]=freqz(numd,dend,Nfreqs);
            Hd=abs(hd);
            fd=Wd*fs/(2*pi);
            
        %provera gabarita
            NOOK = 0;
            POOK = 0;
            df=(fs/2)/Nfreqs;           %korak
   
            %odredjivanje koeficijenata  niza
            
            ip1=ceil(fp(1)/df)+1;            %koeficijent za kraj propusnog
            ia1=floor(fa(1)/df)+1;          %koeficijent za pocetak nepropusnog
            ia2=ceil(fa(2)/df)+1;               %koeficijent za kraj nepropusnog
            ip2=floor(fp(2)/df)+1;              %koeficijent za pocetak propusnog
            Ha=Hd(ia1:ia2);               %opseg koeficijenata nepropusnog
            Hp=[Hd(1:ip1)' Hd(ip2:end)'];   %opseg koeficijenata propusnog

            maxbs = max(20*log10(Ha));      
            minbp = min(20*log10(Hp));
    
            %provera stabilnosti i promena parametara 
            
            if(maxbs > -Ap)
                    
                    Aaglobalno=Aaglobalno-parametar;                
                    Aapomocno=Aaglobalno;
                     
            end
            
            
            if(maxbs >-Aaglobalno)
                Aapomocno=Aapomocno+0.1;
            else
                NOOK=1;
            end
            if(minbp<-Ap)                   %obrati paznju na slucaj za Appom=0.1
                Appomocno=Appomocno-0.1;
                
            else
                POOK=1;
            end
            
            if((NOOK==1)&&(POOK==1))
                break
            end
   



end
b=numd;
a=dend;

 end




